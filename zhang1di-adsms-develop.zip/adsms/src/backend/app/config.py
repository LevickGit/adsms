import os


class Config(object):
    DEBUG = False
    """Token过期时间"""
    TOKEN_EXPIRED_TIME = 60 * 60 * 2  # 两小时
    """
    Token刷新剩余时间，
    当Token剩余时间小于这个值的时候发生请求，会重新刷新Token过期时间
    """
    TOKEN_REST_REFRESH_TIME = 60 * 30  # 半小时
    """用户默认头像"""
    DEFAULT_AVATAR_URL = 'http://hbimg.huabanimg.com/69ad7a731f43d4b8729f1a2fbe65c43801ca0f033250-EV1vMf_fw658'
    WTF_CSRF_CHECK_DEFAULT = False
    SECRET_KEY = 'ahdalshdlh'
    UPLOAD_RESOURCE_PATH = os.getenv('UPLOAD_RESOURCE_PATH') or '/srv/static/uploads'
    STATIC_RESOURCE_CONTEXT = os.getenv('STATIC_RESOURCE_CONTEXT') or '/uploads'

    MONGODB_SETTINGS = {
        'db': os.getenv('MONGODB_DB') or 'adsms',
        'host': os.getenv('MONGODB_HOST') or 'localhost',
        'username': os.getenv('MONGODB_USERNAME') or 'root',
        'password': os.getenv('MONGODB_PASSWORD') or 'root',
        'authentication_source': 'admin'
    }

