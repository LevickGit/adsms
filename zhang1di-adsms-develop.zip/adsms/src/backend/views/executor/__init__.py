from concurrent.futures import ThreadPoolExecutor

executor = ThreadPoolExecutor(2)
