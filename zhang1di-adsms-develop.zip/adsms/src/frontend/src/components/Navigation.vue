<template>
  <nav class="navbar-default navbar-static-side" role="navigation">
    <ul class="nav metismenu" id="side-menu" ref="menu">
      <li class="nav-header">
        <div class="dropdown profile-element">
          <span class="clear">
            <span class="block m-t-xs">
              <strong class="font-bold username">{{username}}</strong>
            </span>
            <span class="text-muted small block">{{role}}</span>
          </span>
        </div>
      </li>
      <li :class="navActive('/appliance')">
        <router-link to="/appliance">
          <i class="el-icon-s-cooperation"></i>
          <span class="nav-label">器材管理</span>
        </router-link>
      </li>
      <li :class="navActive('/template')">
        <router-link to="/template">
          <i class="el-icon-s-order"></i>
          <span class="nav-label">模板管理</span>
        </router-link>
      </li>
      <li v-role:admin :class="navActive('/system/setup')">
        <router-link to="/system/setup">
          <i class="fa fa-th-large"></i>
          <span class="nav-label">系统设置</span>
        </router-link>
      </li>
      <li v-role:admin :class="navActive('/account/list')">
        <router-link to="/account/list">
          <i class="el-icon-s-custom"></i>
          <span class="nav-label">用户管理</span>
        </router-link>
      </li>
      <li :class="navActive('/account/profile')">
        <router-link to="/account/profile">
          <i class="el-icon-setting"></i>
          <span class="nav-label">个人中心</span>
        </router-link>
      </li>
      <li :class="navActive('/recycles')">
        <router-link to="/recycles">
          <i class="el-icon-house"></i>
          <span class="nav-label">回收站</span>
        </router-link>
      </li>
    </ul>
  </nav>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  props: ['path'],
  mounted () {
    const { menu } = this.$refs
    $(menu).metisMenu()
  },
  computed: {
    ...mapGetters(['username', 'role'])
  },
  methods: {
    navActive (path) {
      return this.path === path ? 'active' : ''
    }
  }
}
</script>

<style scoped>
.dropdown span {
  color: #DFE4ED;
}

.username {
  letter-spacing: 2px;
}
</style>
