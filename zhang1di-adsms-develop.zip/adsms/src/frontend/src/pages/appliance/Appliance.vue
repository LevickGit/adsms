<template>
  <main-layout>
    <div class="row">
      <div class="col-lg-12">
        <div class="ibox">
          <div class="ibox-title">
            <h5>器材列表</h5>
          </div>
          <div class="ibox-content">
            <div class="row">
              <div class="col-sm-5 m-b-xs">
                <div class="input-group align-left">
                  <el-input class="handle-input m-r-sm" clearable @clear="simpleSearch" v-model="searchKey" placeholder="名称/备注"></el-input>
                  <el-button type="primary" icon="el-icon-search" @click="simpleSearch">简单搜索</el-button>
                  <el-button type="primary" icon="el-icon-s-unfold" @click="showSearch=!showSearch">{{showSearch ? '隐藏' : '展开'}}高级搜索</el-button>
                </div>
              </div>
            </div>
            <div class="row" v-show="showSearch">
              <div class="complexSearchPages col-sm-10 m-b-xs">
                <div class="tags-wrapper m-sm" v-if="showConditionTags">
                  <label>筛选条件：</label>
                  <el-tag
                    class="m-xs"
                    type="success"
                    effect="plain"
                    closable
                    :key="condition.name"
                    @close="resetCondition(condition.field)"
                    v-for="condition in currentConditionTags"
                  ><span class="condition-name">{{condition.name}}: </span><span class="condition-value">{{condition.value}}</span></el-tag>
                </div>
                <template v-else>
                  <div class="searchBox m-t-xl animated fadeIn">
                    <el-form :model="condition" class="search-form" label-width="80px">
                      <el-form-item label="名称" v-if="isCurrentField('name')">
                        <el-input v-model="condition.name.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="信号类型" v-if="isCurrentField('signalType')">
                        <el-input v-model="condition.signalType.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="屏蔽类型" v-if="isCurrentField('shieldType')">
                        <el-select class="full-width" v-model="condition.shieldType.value" filterable>
                          <el-option
                            v-for="type in systemShieldTypes"
                            :key="type"
                            :label="type"
                            :value="type"
                            clearable
                          ></el-option>
                        </el-select>
                      </el-form-item>
                      <el-form-item label="类型" v-if="isCurrentField('type')">
                        <el-input v-model="condition.type.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="接口协议" v-if="isCurrentField('protocol')">
                        <el-select class="full-width" v-model="condition.protocol.value" filterable>
                          <el-option
                            v-for="protocol in systemInterfaceProtocol"
                            :key="protocol"
                            :label="protocol"
                            :value="protocol"
                            clearable
                          ></el-option>
                        </el-select>
                      </el-form-item>
                      <el-form-item label="位置" v-if="isCurrentField('location')">
                        <el-input v-model="condition.location.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="PCL" v-if="isCurrentField('pcl')">
                        <el-input v-model="condition.pcl.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="设备系统" v-if="isCurrentField('system')">
                        <el-input v-model="condition.system.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="序列号" v-if="isCurrentField('sn')">
                        <el-input v-model="condition.sn.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="生产厂商" v-if="isCurrentField('manufacturer')">
                        <el-input v-model="condition.manufacturer.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="备注" v-if="isCurrentField('note')">
                        <el-input v-model="condition.note.value" clearable></el-input>
                      </el-form-item>
                      <el-form-item label="创建者" v-if="isCurrentField('createUser')">
                        <el-cascader
                          class="full-width"
                          v-model="condition.createUser.value"
                          :options="usersMeta"
                          placeholder="姓名 - 邮箱"
                          :filter-method="({ data }, keyword) => data.username.includes(keyword) || data.email.includes(keyword)"
                          clearable
                          filterable>
                          <template slot-scope="{ data }">
                            <div class="username">{{ data.username }}</div>
                            <span class="email">{{ data.email }}</span>
                          </template>
                        </el-cascader>
                      </el-form-item>
                      <el-form-item label="父级装置" v-if="isCurrentField('parentEquipment')">
                        <el-cascader
                          class="full-width"
                          v-model="condition.parentEquipment.value"
                          :options="equipmentMeta"
                          clearable
                          filterable>
                        </el-cascader>
                      </el-form-item>
                      <el-form-item label="父级设备" v-if="isCurrentField('parentDevice')">
                        <el-cascader
                          class="full-width"
                          v-model="condition.parentDevice.value"
                          :options="deviceMeta"
                          :props="{ checkStrictly: true }"
                          clearable
                          filterable>
                        </el-cascader>
                      </el-form-item>
                      <el-form-item label="起始接口" v-if="isCurrentField('startInterface')">
                        <el-cascader
                          class="full-width"
                          v-model="condition.startInterface.value"
                          :options="interfaceMeta"
                          :props="{ checkStrictly: true }"
                          clearable
                          filterable>
                        </el-cascader>
                      </el-form-item>
                      <el-form-item label="终止接口" v-if="isCurrentField('endInterface')">
                        <el-cascader
                          class="full-width"
                          v-model="condition.endInterface.value"
                          :options="interfaceMeta"
                          :props="{ checkStrictly: true }"
                          clearable
                          filterable>
                        </el-cascader>
                      </el-form-item>
                      <el-form-item label="创建时间" v-if="isCurrentField('createTime')">
                        <el-date-picker
                          type="datetimerange"
                          align="right"
                          v-model="condition.createTime.value"
                          :picker-options="pickerOptions"
                          start-placeholder="开始时间"
                          end-placeholder="结束时间"
                          :default-time="['00:00:00', '23:59:59']">
                        </el-date-picker>
                      </el-form-item>
                    </el-form>
                  </div>
                  <div class="search-wrapper">
                    <el-button type="success" icon="el-icon-search" @click="advancedSearch">立即搜索</el-button>
                    <el-button type="success" icon="el-icon-refresh-right" @click="resetAdvancedSearch">重置条件</el-button>
                  </div>
                </template>
              </div>
            </div>
          </div>
          <div class="ibox-content">
            <el-tabs type="border-card" @tab-click="tabChange" :value="activeName">
              <el-tab-pane label="装置" name="equipment">
                <span slot="label">
                  <el-badge :value="equipmentTotalCount" :max="99" class="item">
                    <i class="el-icon-copy-document"> 装置</i>
                  </el-badge>
                </span>
                <Equipment-list ref="myequipment"></Equipment-list>
              </el-tab-pane>
              <el-tab-pane label="设备" name="device">
                <span slot="label">
                  <el-badge :value="deviceTotalCount" :max="99" class="item">
                    <i class="el-icon-receiving"> 设备</i>
                  </el-badge>
                </span>
                <Device-list ref="mydevice"></Device-list>
              </el-tab-pane>
              <el-tab-pane label="接口" name="interface">
                <span slot="label" name="third" label="接口">
                  <el-badge :value="interfaceTotalCount" :max="99" class="item">
                    <i class="el-icon-link"> 接口</i>
                  </el-badge>
                </span>
                <Interface-list ref="myinterface"></Interface-list>
              </el-tab-pane>
              <el-tab-pane label="线缆" name="cable">
                <span slot="label" name="fourth" label="线缆">
                  <el-badge :value="cableTotalCount" :max="99" class="item">
                    <i class="el-icon-connection"> 线缆</i>
                  </el-badge>
                </span>
                <Cable-list ref="mycable"></Cable-list>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </div>
    </div>
  </main-layout>
</template>

<script>
import { mapGetters } from 'vuex'
import { formatTime } from '@/utils/tools'
import CableList from './cable/List.vue'
import DeviceList from './device/List'
import EquipmentList from './equipment/List.vue'
import InterfaceList from './interface/List.vue'

export default {
  data: () => ({
    showSearch: false,
    searchKey: '',
    showConditionTags: false,
    fields: {
      common: ['name', 'note', 'createUser', 'createTime'],
      cable: ['signalType', 'shieldType', 'startInterface', 'endInterface'],
      device: ['type', 'location', 'system', 'sn', 'manufacturer', 'parentEquipment'],
      interface: ['type', 'protocol', 'location', 'pcl', 'parentDevice'],
      equipment: ['type', 'location', 'sn', 'manufacturer']
    },
    condition: {
      name: { name: '名称', value: '' },
      type: { name: '类型', value: '' },
      signalType: { name: '信号类型', value: '' },
      shieldType: { name: '屏蔽类型', value: '' },
      protocol: { name: '接口协议', value: '' },
      location: { name: '位置', value: '' },
      pcl: { name: 'PCL', value: '' },
      system: { name: '设备系统', value: '' },
      sn: { name: '序列号', value: '' },
      manufacturer: { name: '生产厂商', value: '' },
      note: { name: '备注', value: '' },
      createTime: { name: '创建时间', value: '' },
      createUser: { name: '创建者', value: '' },
      parentEquipment: { name: '父级', value: '' },
      parentDevice: { name: '父级', value: '' },
      startInterface: { name: '起始', value: '' },
      endInterface: { name: '终止', value: '' }
    },
    pickerOptions: {
      shortcuts: [{
        text: '最近一周',
        onClick (picker) {
          const end = new Date()
          const start = new Date()
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
          picker.$emit('pick', [start, end])
        }
      }, {
        text: '最近一个月',
        onClick (picker) {
          const end = new Date()
          const start = new Date()
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
          picker.$emit('pick', [start, end])
        }
      }, {
        text: '最近三个月',
        onClick (picker) {
          const end = new Date()
          const start = new Date()
          start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
          picker.$emit('pick', [start, end])
        }
      }]
    }
  }),
  computed: {
    ...mapGetters([
      'equipmentTotalCount',
      'deviceTotalCount',
      'interfaceTotalCount',
      'cableTotalCount',
      'usersMeta',
      'deviceMeta',
      'interfaceMeta',
      'equipmentMeta',
      'applianceMeta',
      'systemShieldTypes',
      'systemInterfaceProtocol'
    ]),
    activeName () {
      return this.$route.query.tab || 'equipment'
    },
    currentFields () {
      return this.fields.common.concat(this.fields[this.activeName])
    },
    currentCondition () {
      let condition = {}
      this.currentFields.filter(field => {
        let value = this.condition[field].value
        return !!value && !!value.length
      }).forEach(field => {
        let value = this.condition[field].value
        if (field === 'createTime') {
          condition['createdAtStart'] = formatTime(value[0])
          condition['createdAtEnd'] = formatTime(value[1])
        } else if (field === 'createUser') {
          condition['createUserId'] = value[0]
        } else if (field.startsWith('parent')) {
          condition = this.formatSelectedMeta('parent', value, condition)
        } else if (field.startsWith('start')) {
          condition = this.formatSelectedMeta('start', value, condition)
        } else if (field.startsWith('end')) {
          condition = this.formatSelectedMeta('end', value, condition)
        } else {
          condition[field] = value
        }
      })
      return condition
    },
    currentConditionTags () {
      let translate = ['', '装置', '设备', '接口']
      return this.currentFields.filter(field => {
        let value = this.condition[field].value
        return value && value.length
      }).map(field => {
        let value = this.condition[field].value
        let tag = { field, name: this.condition[field].name }
        switch (field) {
          case 'createTime':
            tag.value = `${formatTime(value[0])} 至 ${formatTime(value[1])}`
            break
          case 'createUser':
            let userMeta = this.usersMeta.find(userMeta => userMeta.value === value[0])
            tag.value = userMeta && userMeta.username
            break
          case 'parentEquipment':
          case 'parentDevice':
          case 'startInterface':
          case 'endInterface':
            tag.name = tag.name + translate[value.length]
            if (value.length === 1) {
              tag.value = this.applianceMeta.equipment.find(i => i.id === value[0]).name
            } else if (value.length === 2) {
              tag.value = this.applianceMeta.device.find(i => i.id === value[1]).name
            } else if (value.length === 3) {
              tag.value = this.applianceMeta.interface.find(i => i.id === value[2]).name
            }
            break
          default: tag.value = value
        }
        return tag
      })
    }
  },
  components: { CableList, DeviceList, EquipmentList, InterfaceList },
  methods: {
    simpleSearch () {
      this.eventHub.$emit('search:appliance', {
        name: this.activeName,
        type: 'simple',
        condition: {
          searchKey: this.searchKey
        }
      })
    },
    advancedSearch () {
      this.eventHub.$emit('search:appliance', {
        name: this.activeName,
        type: 'advanced',
        condition: this.currentCondition
      })
      this.showConditionTags = this.currentConditionTags.length > 0
    },
    resetCondition (field) {
      if (this.condition[field]) {
        this.condition[field].value = null
        this.advancedSearch()
      }
    },
    resetAdvancedSearch () {
      for (let key of this.currentFields) {
        this.condition[key].value = null
      }
    },
    tabChange ({ name }) {
      this.$router.push({
        name: this.$route.name,
        query: {
          ...this.$route.query,
          tab: name
        }
      })
      this.showConditionTags = false
    },
    isCurrentField (name) {
      return this.currentFields.includes(name)
    },
    /* eslint-disable no-fallthrough */
    formatSelectedMeta (prefix, value, condition = {}) {
      switch (value && value.length) {
        case 3: condition[`${prefix}InterfaceId`] = value[2]
        case 2: condition[`${prefix}DeviceId`] = value[1]
        case 1: condition[`${prefix}EquipmentId`] = value[0]
      }
      return condition
    }
  }
}
</script>

<style lang="scss">
.name-link {
  display: block;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.el-table a {
  font-size: inherit;
}

.el-cascader-node {
  height: auto;
  padding-top: 3px;
  padding-bottom: 3px;

  .username {
    text-overflow: ellipsis;
    line-height: 100%;
    overflow: hidden;
  }
  .email {
    font-size: 12px;
    color: #b4b4b4;
  }
}

.tags-wrapper {
  display: flex;
  flex-flow: row wrap;
  align-items: center;
  font-size: 14px;

  .condition-name {
    color: #333333;
  }

  label {
    margin-bottom: 0;
  }
}

.search-wrapper {
  display: flex;
  justify-content: flex-end;
}

.search-form {
  display: flex;
  flex-flow: row wrap;

  .el-form-item {
    width: 33.33%;
  }
}
.handle-select {
  width: calc((100% - 20px) / 2);
}
.handle-input {
  width: calc(100% - 83px);
}

.align-between {
  justify-content: space-between;
}

.align-left {
  justify-content: flex-start;
}

.range-group{
  margin-right:-150px;
  padding-right:0;
}

.item {
  margin: 10px 40px 10px 20px;
}

.complexSearchPages{
  margin-top: 5px;
}
</style>
