<template>
  <main-layout :crumbs="[{
    title: '线缆管理',
    path: '/appliance?tab=cable'
  }, {
    title: $route.query.id ? '更新线缆' : '新增线缆'
  }]">
    <div class="container-fluid">
      <div class="row">
        <div class="el-col-9 el-col-offset-2">
          <h2 class="text-center">线缆基本信息录入</h2>
          <el-form :model="cableInfo"  status-icon :rules="rules" ref="form" label-width="100px" size="medium">
            <el-form-item label="线缆名称：" focus prop="name" >
              <el-input name="name" type="text" v-model.trim="cableInfo.name" autocomplete="on"></el-input>
            </el-form-item>
            <el-form-item label="信号类型：" prop="signalType"  >
              <el-input name="signalType" type="text" v-model.trim="cableInfo.signalType" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="屏蔽类型：" prop="shieldType"  >
              <el-select v-model.trim="cableInfo.shieldType" clearable placeholder="请选择">
                <el-option
                  v-for="item in options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="是否定制：">
              <el-radio-group name="isCustom" v-model.lazy="cableInfo.isCustom">
                <el-radio :label="true">是</el-radio>
                <el-radio :label="false">否</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="定制参数：" v-if="cableInfo.isCustom === true">
              <el-input
                type="textarea"
                :row="3"
                aria-placeholder="请输入定制参数"
                v-model.trim="cableInfo.parameterList"
                >
              </el-input>
            </el-form-item>
            <el-form-item label="起始接口：" prop="note">
              <el-cascader
                class="full-width"
                v-model="cableInfo.startParent"
                placeholder="设备名/装置名/接口名"
                :options="interfaceMeta"
                filterable>
              </el-cascader>
            </el-form-item>
            <el-form-item label="终止接口：" prop="note">
              <el-cascader
                class="full-width"
                v-model="cableInfo.endParent"
                placeholder="设备名/装置名/接口名"
                :options="interfaceMeta"
                filterable>
              </el-cascader>
            </el-form-item>
            <el-form-item label="备注：" prop="note" >
              <el-input name="note" :show-word-limit="true" :maxlength="100" type="textarea" :autosize="{ minRows: 2, maxRows: 5}" v-model.trim="cableInfo.note"></el-input>
            </el-form-item>
            <el-form-item class="text-center">
              <el-button size="large" type="primary" @click="submit">提交</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="el-col-9 el-col-offset-2 text-center">
          <h2 class="text-center">线缆模板筛选</h2>
          <el-input placeholder="请输入关键字" v-model="condition.searchKey" clearable>
            <el-button ref="signleTable" slot="append" @click="fetchTableList()">检索</el-button>
          </el-input>
          <el-table :data="templateInfo" max-height="600" border style="width: 100%" highlight-current-row>
            <el-table-column prop="name" label="模板名称" width="100"></el-table-column>
            <el-table-column prop="shieldType" label="线缆类型"></el-table-column>
            <el-table-column prop="signalType" label="信号类型"></el-table-column>
            <el-table-column width="100" prop="createUserName" label="创建者"></el-table-column>
            <el-table-column label="操作" width="96" fixed="right">
              <template slot-scope="scope">
                <el-button type="primary" size="small" @click="useTemplate(scope.$index, scope.row)">使用模板</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
  </main-layout>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'appliance-interface-create',
  data: () => ({
    keyword: '',
    cableInfo: {
      name: '',
      signalType: '',
      shieldType: '',
      note: '',
      isCustom: false,
      parameterList: '',
      startParent: '',
      endParent: ''
    },
    rules: {
      name: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      signalType: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      shieldType: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      isCustom: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      parameterList: [{ required: false, message: '此字段不能为空', trigger: 'blur' }],
      startParent: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      endParent: [{ required: true, message: '此字段不能为空', trigger: 'blur' }]
    },
    templateInfo: [],
    condition: {
      searchKey: '',
      verified: 'true'
    },
    options: {
      value: '',
      label: ''
    }
  }),
  computed: {
    ...mapGetters(['interfaceMeta', 'systemShieldTypes'])
  },
  created () {
    if (this.$route.query.id) {
      this.fetchCable(this.$route.query.id)
    }
  },
  mounted () {
    this.fetchTableList()
    this.decorateShieldType()
  },
  methods: {
    useTemplate (index, row) {
      this.cableInfo = row
    },
    async decorateShieldType () {
      this.options = this.systemShieldTypes.map((v) => { return { value: v, label: v } })
    },
    async fetchTableList (condition = this.condition) {
      let result = await this.$axios.get('appliance/cable/templates', {
        params: {
          ...condition
        }
      })
      this.templateInfo = result.items.map(item => ({
        ...item
      }))
    },
    submit () {
      this.$refs.form.validate().then(() => {
        let id = this.$route.query.id
        let params = this.formatRequestParams()
        id ? this.$axios.put(`appliance/cable/${id}`, params).then(response => {
          if (response.ok) {
            this.eventHub.$emit('change:cable')
            this.$message.success('更新线缆成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'cable' }
            })
          } else {
            this.$message.error(response.msg)
          }
        }) : this.$axios.post('appliance/cable', params).then(response => {
          if (response.ok) {
            this.eventHub.$emit('change:cable')
            this.$message.success('创建线缆成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'cable' }
            })
          } else {
            this.$message.error(response.msg)
          }
        })
      })
    },
    fetchCable (id) {
      this.$axios.get(`appliance/cable/${id}`).then(cable => {
        this.cableInfo.name = cable.name
        this.cableInfo.signalType = cable.signalType
        this.cableInfo.shieldType = cable.shieldType
        this.cableInfo.note = cable.note
        this.cableInfo.isCustom = cable.isCustom
        this.cableInfo.parameterList = cable.parameterList
        this.cableInfo.startParent = [
          cable.startEquipment.id,
          cable.startDevice.id,
          cable.startInterface.id
        ]
        this.cableInfo.endParent = [
          cable.endEquipment.id,
          cable.endDevice.id,
          cable.endInterface.id
        ]
      })
    },
    formatRequestParams () {
      return {
        name: this.cableInfo.name,
        signalType: this.cableInfo.signalType,
        shieldType: this.cableInfo.shieldType,
        note: this.cableInfo.note,
        isCustom: this.cableInfo.isCustom,
        parameterList: this.cableInfo.isCustom ? this.cableInfo.parameterList : '',
        startInterfaceId: this.cableInfo.startParent[2],
        endInterfaceId: this.cableInfo.endParent[2]
      }
    }
  }
}
</script>

<style lang="scss">
.el-radio {
  margin-bottom: 0;
}
</style>
