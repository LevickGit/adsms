<template>
    <div class="appliance-device">
        <div class="row">
            <div class="col-sm-8 m-b-xs">
              <el-button type="primary" icon="el-icon-check" @click="copyTemplated">复刻为模板</el-button>
              <router-link to="/appliance/device/create-or-update">
                <el-button class="createButton" type="success" icon="el-icon-plus">新增</el-button>
              </router-link>
            </div>
        </div>
        <div class="table-responsive">
          <el-table ref="multipleTable" @sort-change="sortList" :data="tableList" @selection-change="handleSelectionChange" height="400" border tooltip-effect="dark" style="width: 100%">
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="name" sortable="custom" label="设备名称" width="auto" show-overflow-tooltip>
              <template slot-scope="scope">
                <el-link @click=showDetails(scope.row)>{{scope.row.name}}</el-link>
              </template>
            </el-table-column>
            <el-table-column prop="type" label="设备类型" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="location" label="设备位置" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="system" label="设备系统" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="sn" sortable="custom" label="序列号" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="manufacturer" label="生产厂商" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="note" label="备注" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="createUserName" label="创建者" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="parentEquipmentName" label="父级装置" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="createdAt" sortable="custom" label="创建时间" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="updatedAt" sortable="custom" label="更新时间" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column label="操作" width="150">
              <template slot-scope="scope" align="center">
                <el-link @click="$router.push({
                  name: 'appliance-device-create-or-update',
                    query: { id: scope.row.id }
                  })" icon="el-icon-edit" type="primary" class="m-r-sm">编辑</el-link>
                <el-link @click="handleDelete(scope.row)" type="danger" icon="el-icon-delete">删除</el-link>
              </template>
            </el-table-column>
          </el-table>
          <el-dialog title="设备详细信息" center :visible.sync="showDetailsVisible" width="45%" :modal="true" lock-scroll :modal-append-to-body="false">
          <el-container>
            <el-form :model="deviceInfo" status-icon ref="form" label-width="100px">
              <div class="el-col-24">
                <h3>设备基本信息：</h3>
                <hr/>
                <div class="el-col-12">
                  <el-form-item label="设备名称：" focus prop="name" >
                    <span name="name" type="text" >{{deviceInfo.name}}</span>
                  </el-form-item>
                  <el-form-item label="设备类型：" prop="shieldType"  >
                    <span name="shieldType" type="text" >{{deviceInfo.type}}</span>
                  </el-form-item>
                </div>
                <div class="el-col-12">
                  <el-form-item label="设备位置：" prop="signalType"  >
                    <span name="signalType" type="text" >{{deviceInfo.location}}</span>
                  </el-form-item>
                  <el-form-item label="序列号：">
                    <span name="isCustom" type="text" >{{deviceInfo.sn}}</span>
                  </el-form-item>
                </div>
                <div class="el-col-24">
                  <el-form-item label="生产厂商：" prop="note">
                    <span>{{deviceInfo.manufacturer}}</span>
                  </el-form-item>
                  <el-form-item label="备注：" prop="note" >
                      <el-input  type="textarea" :autosize="{ minRows: 2, maxRows: 5}" v-model.trim="deviceInfo.note" readonly></el-input>
                    </el-form-item>
                </div>
              </div>
              <div class="el-col-24">
                <h3>设备所属器材信息：</h3>
              <hr />
                <el-form-item label="所属装置：" prop="note">
                  <span name="startEquipment" type="text" >{{deviceInfo.parentEquipmentName}}<br/></span>
                </el-form-item>
              </div>
              <div class="col-lg-24">
                <h3>设备其他信息：</h3>
                <hr/>
                <div class="el-col-12">
                  <el-form-item label="创建者：" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{deviceInfo.createUserName}}</span>
                  </el-form-item>
                  <el-form-item label="创建时间" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{deviceInfo.createdAt}}</span>
                  </el-form-item>
                </div>
                <div class="el-col-12">
                  <el-form-item label="更新者：" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{deviceInfo.updateUserName}}</span>
                  </el-form-item>
                  <el-form-item label="更新时间" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{deviceInfo.updatedAt}}</span>
                  </el-form-item>
                  <el-form-item label="更新次数" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{deviceInfo.updateNum}}</span>
                  </el-form-item>
                </div>
              </div>
            </el-form>
          </el-container>
        </el-dialog>
        </div>
        <div class="row table-pagination m-t-xs m-r-xs">
            <el-pagination
            @size-change="fetchTableList(1)"
            @current-change="fetchTableList"
            @prev-click="fetchLastPage(pagination.page - 1)"
            @next-click="fetchNextPage(pagination.page + 1)"
            :page-sizes="[10, 20, 50, 100]"
            layout="total, sizes, prev, pager, next, jumper"
            :total="pagination.totalCount"
            :page-size.sync="pageSize"
            :current-page="pagination.page">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import { formatTime } from '@/utils/tools'

export default {
  name: 'appliance-device',
  data: () => ({
    tableList: [],
    multipleSelection: [],
    condition: {},
    orderBy: {},
    deviceSelection: [],
    deleteVisible: false,
    interfaces: '',
    cable: '',
    showDetailsVisible: false,
    deviceInfo: {
      name: '',
      type: '',
      location: '',
      sn: '',
      note: '',
      system: '',
      manufacturer: '',
      parentEquipmentName: '',
      createUserName: '',
      updateUserName: '',
      createdAt: '',
      updatedAt: '',
      updateNum: ''
    }
  }),
  computed: {
    ...mapGetters({ pagination: 'devicePagination' }),
    pageSize: {
      get () {
        return this.pagination.pageSize
      },
      set (pageSize) {
        this.updatePagination({ ...this.pagination, pageSize })
      }
    }
  },
  mounted () {
    this.fetchTableList()
    this.eventHub.$on('search:appliance', ({ name, condition }) => {
      name === 'device' && this.fetchTableList(1, condition)
    })
  },
  methods: {
    ...mapMutations({ updatePagination: 'updateDevicePagination' }),
    sortList ({ prop, order }) {
      prop = prop.replace(/([A-Z])/g, '_$1').toLowerCase()
      this.orderBy = {
        [prop]: order === 'descending' ? 'desc' : 'asc'
      }
      this.fetchTableList(this.pagination.page)
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    handleDelete ({ id }) {
      this.searchRelation(id).then(() => {
        this.$confirm('此设备存在 ' + this.interfaces + ' 个接口和 ' + this.cable + ' 个线缆, 是否确认删除?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          return this.deleteDevice(id)
        })
      })
    },
    async searchRelation (id) {
      this.result = await this.$axios.get('appliance/device/child/' + id)
      this.interfaces = this.result.msg.interface
      this.cable = this.result.msg.cable
    },
    async deleteDevice (id) {
      try {
        await this.$axios.delete(`appliance/device/${id}`)
        this.eventHub.$emit('change:device')
        await this.fetchTableList()
        this.$message.success('删除成功')
      } catch (error) {
        this.$message.warn('设备不存在')
      }
    },
    async copyTemplated () {
      if (this.multipleSelection.length < 1) {
        this.$message({
          type: 'warning',
          message: '您未选择任何设备'
        })
      } else {
        var deviceSelection = this.multipleSelection.map(function (item) {
          return item['id']
        })
        try {
          await this.$axios.post(`appliance/device/templates`, {
            ids: deviceSelection
          })
          this.$message.success('复刻成功')
        } catch (error) {
          this.$message.warn('复刻失败')
        }
      }
    },
    async fetchTableList (page = 1, condition = this.condition) {
      let result = await this.$axios.get('/appliance/devices', {
        params: {
          ...condition,
          page: page,
          orderBy: JSON.stringify(this.orderBy),
          pageSize: this.pagination.pageSize
        }
      })
      this.tableList = result.items.map(item => ({
        ...item,
        createdAt: formatTime(item.createdAt),
        updatedAt: formatTime(item.updatedAt)
      }))
      this.updatePagination(result.meta)
    },
    async showDetails (row, index) {
      try {
        let result = await this.$axios.get(`/appliance/device/${row.id}`)
        this.deviceInfo = result
        this.deviceInfo.parentEquipmentName = result.parentEquipment.name
        this.deviceInfo.createdAt = formatTime(result.createdAt)
        this.deviceInfo.updatedAt = formatTime(result.updatedAt)
        this.showDetailsVisible = true
      } catch (error) {
        this.$message.error('没有找到该装置！')
      }
    }
  }
}
</script>

<style scoped>
hr {
  border-top: 1px dotted rgb(47, 64, 80)
}
</style>
