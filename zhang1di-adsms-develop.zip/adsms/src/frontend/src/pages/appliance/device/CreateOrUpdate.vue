<template>
  <main-layout :crumbs="[{
    title: '器材管理',
    path: '/appliance?tab=device'
  }, {
    title: $route.query.id ? '更新设备' : '新增设备'
  }]">
    <div class="container-fluid">
      <div class="row">
        <div class=" el-col-9 el-col-offset-2 text-center">
          <h2 class="text-center">设备信息录入</h2>
          <el-form :model="deviceInfo" status-icon :rules="rules" ref="form" label-width="100px" size="medium">
            <el-form-item label="设备名称：" focus prop="name" >
              <el-input name="name" type="text" v-model.trim="deviceInfo.name" autocomplete="on"></el-input>
            </el-form-item>
            <el-form-item label="设备类型：" prop="type">
              <el-input name="type" type="text" v-model.trim="deviceInfo.type" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="设备位置：" prop="location"  >
              <el-input name="location" type="text" v-model.trim="deviceInfo.location"></el-input>
            </el-form-item>
            <el-form-item label="设备系统："  prop="system">
              <el-input name="system" type="text" v-model.trim="deviceInfo.system" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="序列号："  prop="serial" >
              <el-input name="sn" type="text" v-model.trim="deviceInfo.sn" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="生产厂商："  prop="manufacturer">
              <el-input name="manufacturer" type="text" v-model.trim="deviceInfo.manufacturer"></el-input>
            </el-form-item>
            <el-form-item label="备注：" prop="remarks" >
              <el-input name="note" type="textarea" :show-word-limit="true" :maxlength="100" :autosize="{ minRows: 2, maxRows: 4}" v-model.trim="deviceInfo.note"></el-input>
            </el-form-item>
            <el-form-item label="父级装置：" prop="remarks" >
              <el-cascader
                class="full-width"
                v-model="deviceInfo.parent"
                placeholder="设备名"
                :options="equipmentMeta"
                filterable>
              </el-cascader>
            </el-form-item>
            <el-form-item>
              <el-button size="large" type="primary" @click="submit">提交</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="el-col-9 el-col-offset-2 text-center">
          <h2 class="text-center">设备模板筛选</h2>
          <el-input placeholder="请输入关键字" v-model="condition.searchKey">
            <el-button ref="signleTable" slot="append" @click="fetchTableList()">检索</el-button>
          </el-input>
          <el-table :data="templateInfo" max-height="600" border style="width: 100%" highlight-current-row>
            <el-table-column prop="name" label="设备名称" width="100"></el-table-column>
            <el-table-column prop="type" label="设备类型"></el-table-column>
            <el-table-column prop="location" label="设备位置"></el-table-column>
            <el-table-column width="100" prop="createUserName" label="创建者"></el-table-column>
            <el-table-column label="操作" width="96" fixed="right">
              <template slot-scope="scope">
                <el-button type="primary" size="small" @click="useTemplate(scope.$index, scope.row)">使用模板</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
  </main-layout>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'appliance-device-create',
  data: () => ({
    keyword: '',
    deviceInfo: {
      name: '',
      type: '',
      location: '',
      system: '',
      sn: '',
      manufacturer: '',
      note: '',
      parent: ''
    },
    rules: {
      name: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      type: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      location: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      sn: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      system: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      manufacturer: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      note: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      parent: [{ required: true, message: '此字段不能为空', trigger: 'blur' }]
    },
    templateInfo: [],
    condition: {
      searchKey: '',
      verified: 'true'
    }
  }),
  computed: {
    ...mapGetters(['equipmentMeta'])
  },
  created () {
    if (this.$route.query.id) {
      this.fetchDevice(this.$route.query.id)
    }
  },
  mounted () {
    this.fetchTableList()
  },
  methods: {
    useTemplate (index, row) {
      this.deviceInfo = row
    },
    async fetchTableList (condition = this.condition) {
      let result = await this.$axios.get('appliance/device/templates', {
        params: {
          ...condition
        }
      })
      this.templateInfo = result.items.map(item => ({
        ...item
      }))
    },
    submit () {
      this.$refs.form.validate().then(() => {
        let id = this.$route.query.id
        let params = this.formatRequestParams()
        id ? this.$axios.put(`appliance/device/${id}`, params).then(response => {
          if (response.ok) {
            this.eventHub.$emit('change:device')
            this.$message.success('更新设备成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'device' }
            })
          } else {
            this.$message.error(response.msg)
          }
        }) : this.$axios.post('appliance/device', params).then(response => {
          if (response.ok) {
            this.eventHub.$emit('change:device')
            this.$message.success('创建设备成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'device' }
            })
          } else {
            this.$message.error(response.msg)
          }
        })
      })
    },
    fetchDevice (id) {
      this.$axios.get(`appliance/device/${id}`).then(device => {
        this.deviceInfo.name = device.name
        this.deviceInfo.type = device.type
        this.deviceInfo.location = device.location
        this.deviceInfo.system = device.system
        this.deviceInfo.sn = device.sn
        this.deviceInfo.manufacturer = device.manufacturer
        this.deviceInfo.note = device.note
        this.deviceInfo.parent = [device.parentEquipment.id]
      })
    },
    formatRequestParams () {
      return {
        name: this.deviceInfo.name,
        type: this.deviceInfo.type,
        location: this.deviceInfo.location,
        system: this.deviceInfo.system,
        sn: this.deviceInfo.sn,
        manufacturer: this.deviceInfo.manufacturer,
        note: this.deviceInfo.note,
        parentEquipmentId: this.deviceInfo.parent[0]
      }
    }
  }
}
</script>
