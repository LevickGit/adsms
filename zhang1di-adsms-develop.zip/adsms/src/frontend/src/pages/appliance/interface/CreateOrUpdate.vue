<template>
  <main-layout :crumbs="[{
    title: '器材管理',
    path: '/appliance?tab=interface'
  }, {
    title: $route.query.id ? '更新接口' : '新增接口'
  }]">
    <div class="container-fluid">
      <div class="row">
        <div class="el-col-9 el-col-offset-2">
          <h2 class="text-center">接口基本信息录入</h2>
          <el-form ref="form" :model="interfaceInfo" status-icon :rules="rules" label-width="100px" size="medium">
            <el-form-item label="接口名称：" focus prop="name">
              <el-input name="name" v-model.trim="interfaceInfo.name" type="text" autocomplete="on" />
            </el-form-item>
            <el-form-item label="接头类型：" prop="type">
              <el-select v-model.trim="interfaceInfo.type" clearable placeholder="请选择">
                <el-option
                  v-for="item in SpliceTypesOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="接口协议：" prop="protocol">
              <el-select v-model.trim="interfaceInfo.protocol" clearable placeholder="请选择">
                <el-option
                  v-for="item in ProtocolOptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item label="接口位置：" prop="location">
              <el-input name="location" v-model.trim="interfaceInfo.location" autocomplete="off"/>
            </el-form-item>
            <el-form-item label="PCL：" prop="pcl">
              <el-input name="pcl" v-model.trim="interfaceInfo.pcl" type="text" autocomplete="off"/>
            </el-form-item>
            <el-form-item label="父级装置：" prop="note">
              <el-cascader
                class="full-width"
                v-model="interfaceInfo.parent"
                placeholder="装置名/设备名"
                :options="deviceMeta"
                filterable>
              </el-cascader>
            </el-form-item>
            <el-form-item label="备注：" prop="note">
              <el-input name="note" v-model.trim="interfaceInfo.note" :show-word-limit="true" :maxlength="125" type="textarea" :autosize="{ minRows: 2, maxRows: 4}"/>
            </el-form-item>
            <el-form-item>
              <el-button size="large" type="primary" @click="submit">提交</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="el-col-9 el-col-offset-2 text-center">
          <h2 class="text-center">装置模板筛选</h2>
          <el-input placeholder="请输入关键字" v-model="condition.searchKey">
            <el-button ref="signleTable" slot="append" @click="fetchTableList()">检索</el-button>
          </el-input>
          <el-table :data="templateInfo" max-height="600" border style="width: 100%" highlight-current-row>
            <el-table-column prop="name" label="模板名称" width="100"></el-table-column>
            <el-table-column prop="type" label="接口类型"></el-table-column>
            <el-table-column prop="location" label="接口位置"></el-table-column>
            <el-table-column width="100" prop="createUserName" label="创建者"></el-table-column>
            <el-table-column label="操作" width="96" fixed="right">
              <template slot-scope="scope">
                <el-button type="primary" size="small" @click="useTemplate(scope.$index, scope.row)">使用模板</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
  </main-layout>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'ApplianceInterfaceCreate',
  data: () => ({
    keyword: '',
    interfaceInfo: {
      name: '',
      type: '',
      protocol: '',
      location: '',
      pcl: '',
      note: '',
      parent: ''
    },
    rules: {
      name: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      type: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      protocol: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      location: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      pcl: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      note: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      parent: [{ required: true, message: '此字段不能为空', trigger: 'blur' }]
    },
    templateInfo: [],
    condition: {
      searchKey: '',
      verified: 'true'
    },
    SpliceTypesOptions: {
      label: '',
      valule: ''
    },
    ProtocolOptions: {
      label: '',
      value: ''
    }
  }),
  computed: {
    ...mapGetters(['deviceMeta', 'systemSpliceTypes', 'systemInterfaceProtocol'])
  },
  created () {
    if (this.$route.query.id) {
      this.fetchInterface(this.$route.query.id)
    }
  },
  mounted () {
    this.fetchTableList()
    this.fetchOptions()
  },
  methods: {
    useTemplate (index, row) {
      this.interfaceInfo = row
    },
    async fetchOptions () {
      this.SpliceTypesOptions = this.systemSpliceTypes.map((v) => { return { value: v, label: v } })
      this.ProtocolOptions = this.systemInterfaceProtocol.map((v) => { return { value: v, label: v } })
    },
    async fetchTableList (condition = this.condition) {
      let result = await this.$axios.get('appliance/interface/templates', {
        params: {
          ...condition
        }
      })
      this.templateInfo = result.items.map(item => ({
        ...item
      }))
    },
    submit () {
      this.$refs.form.validate().then(() => {
        let id = this.$route.query.id
        let params = this.formatRequestParams()
        id ? this.$axios.put(`appliance/interface/${id}`, params).then(response => {
          if (response.ok) {
            this.eventHub.$emit('change:interface')
            this.$message.success('更新接口成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'interface' }
            })
          } else {
            this.$message.error(response.msg)
          }
        }) : this.$axios.post('appliance/interface', params).then(response => {
          if (response.ok) {
            this.eventHub.$emit('change:interface')
            this.$message.success('创建接口成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'interface' }
            })
          } else {
            this.$message.error(response.msg)
          }
        })
      })
    },
    fetchInterface (id) {
      this.$axios.get(`appliance/interface/${id}`).then(_interface => {
        this.interfaceInfo.name = _interface.name
        this.interfaceInfo.type = _interface.type
        this.interfaceInfo.location = _interface.location
        this.interfaceInfo.protocol = _interface.protocol
        this.interfaceInfo.pcl = _interface.pcl
        this.interfaceInfo.note = _interface.note
        this.interfaceInfo.parent = [_interface.parentEquipment.id, _interface.parentDevice.id]
      })
    },
    formatRequestParams () {
      return {
        name: this.interfaceInfo.name,
        type: this.interfaceInfo.type,
        location: this.interfaceInfo.location,
        protocol: this.interfaceInfo.protocol,
        pcl: this.interfaceInfo.pcl,
        note: this.interfaceInfo.note,
        parentDeviceId: this.interfaceInfo.parent[1]
      }
    }
  }
}
</script>
