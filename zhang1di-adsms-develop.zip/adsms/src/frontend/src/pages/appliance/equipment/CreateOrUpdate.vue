<template>
  <main-layout :crumbs="[{
    title: '器材管理',
    path: '/appliance?tab=equipment'
  }, {
    title: $route.query.id ? '更新装置' : '新增装置'
  }]">
    <div class="container-fluid">
      <div class="row">
        <div class=" el-col-9 el-col-offset-2 text-center">
          <h2 class="text-center">装置信息录入</h2>
          <el-form :model="equipmentInfo" status-icon :rules="rules" ref="form" label-width="100px" size="medium">
            <el-form-item label="装置名称：" focus prop="name">
              <el-input name="name" type="text" v-model.trim="equipmentInfo.name" autocomplete="on"></el-input>
            </el-form-item>
            <el-form-item label="装置类型：" prop="type">
              <el-input name="type" type="text" v-model.trim="equipmentInfo.type" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="装置位置：" prop="location">
              <el-input name="location" type="text" v-model.trim="equipmentInfo.location"></el-input>
            </el-form-item>
            <el-form-item label="序列号：" prop="sn">
              <el-input name="sn" type="text" v-model.trim="equipmentInfo.sn" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="生产厂商：" prop="manufacturer">
              <el-input name="manufacturer" v-model.trim="equipmentInfo.manufacturer"></el-input>
            </el-form-item>
            <el-form-item label="备注：" prop="note">
              <el-input name="note" :show-word-limit="true" :maxlength="100" type="textarea" :autosize="{ minRows: 2, maxRows: 4}" v-model.trim="equipmentInfo.note"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button size="large" type="primary" @click="submit">提交</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="el-col-9 el-col-offset-2 text-center">
          <h2 class="text-center">装置模板筛选</h2>
          <el-input placeholder="请输入关键字" v-model="condition.searchKey">
            <el-button ref="signleTable" slot="append" @click="fetchTableList()">检索</el-button>
          </el-input>
          <el-table :data="templateInfo" max-height="600" border style="width: 100%" highlight-current-row>
            <el-table-column prop="name" label="模板名称" width="100"></el-table-column>
            <el-table-column prop="type" label="装置类型"></el-table-column>
            <el-table-column prop="location" label="装置位置"></el-table-column>
            <el-table-column width="100" prop="createUserName" label="创建者"></el-table-column>
            <el-table-column label="操作" width="96" fixed="right">
              <template slot-scope="scope">
                <el-button type="primary" size="small" @click="useTemplate(scope.$index, scope.row)">使用模板</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
  </main-layout>

</template>

<script>
import { formatTime } from '@/utils/tools'

export default {
  name: 'equipmentManagement',
  data: () => ({
    equipmentInfo: {
      name: '',
      type: '',
      location: '',
      sn: '',
      manufacturer: '',
      note: ''
    },
    rules: {
      name: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      type: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      location: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      sn: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      manufacturer: [{ required: true, message: '此字段不能为空', trigger: 'blur' }],
      note: [{ required: true, message: '此字段不能为空', trigger: 'blur' }]
    },
    templateInfo: [],
    condition: {
      searchKey: '',
      verified: 'true'
    }
  }),
  created () {
    if (this.$route.query.id) {
      this.fetchEquipment(this.$route.query.id)
    }
  },
  mounted () {
    this.fetchTableList()
  },
  methods: {
    useTemplate (index, row) {
      this.equipmentInfo = row
    },
    async fetchTableList (condition = this.condition) {
      let result = await this.$axios.get('appliance/equipment/templates', {
        params: {
          ...condition
        }
      })
      this.templateInfo = result.items.map(item => ({
        ...item,
        createdAt: formatTime(item.createdAt),
        updatedAt: formatTime(item.updatedAt)
      }))
    },
    submit () {
      this.$refs.form.validate().then(() => {
        let id = this.$route.query.id
        id ? this.$axios.put(`appliance/equipment/${id}`, this.equipmentInfo).then(response => {
          if (response.ok) {
            this.eventHub.$emit('change:equipment')
            this.$message.success('更新装置成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'equipment' }
            })
          } else {
            this.$message.error(response.msg)
          }
        }) : this.$axios.post('appliance/equipment', this.equipmentInfo).then(response => {
          if (response.ok) {
            this.eventHub.$emit('change:equipment')
            this.$message.success('创建装置成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'equipment' }
            })
          } else {
            this.$message.error(response.msg)
          }
        })
      })
    },
    fetchEquipment (id) {
      this.$axios.get(`appliance/equipment/${id}`).then(equipment => {
        this.equipmentInfo.name = equipment.name
        this.equipmentInfo.type = equipment.type
        this.equipmentInfo.location = equipment.location
        this.equipmentInfo.sn = equipment.sn
        this.equipmentInfo.manufacturer = equipment.manufacturer
        this.equipmentInfo.note = equipment.note
      })
    }
  }
}
</script>
