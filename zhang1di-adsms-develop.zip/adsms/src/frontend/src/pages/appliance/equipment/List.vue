<template>
  <div class="appliance-equipment">
    <div class="row">
      <div class="col-sm-8 m-b-xs">
        <el-button type="primary" icon="el-icon-check" @click="copyTemplated">复刻为模板</el-button>
        <router-link to="/appliance/equipment/create-or-update">
          <el-button class="createButton" type="success" icon="el-icon-plus">新增</el-button>
        </router-link>
      </div>
    </div>
    <div class="table-responsive">
      <el-table ref="multipleTable" @sort-change="sortList" :data="tableList" @selection-change="handleSelectionChange" height="400" border tooltip-effect="dark" style="width: 100%">
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="name" sortable="custom" label="装置名称" width=auto>
          <template slot-scope="scope">
            <el-link class="name-link" @click=showDetails(scope.row)>{{scope.row.name}}</el-link>
          </template>
        </el-table-column>
        <el-table-column prop="type" label="装置类型" width=auto show-overflow-tooltip></el-table-column>
        <el-table-column prop="location" label="装置位置" width=auto show-overflow-tooltip></el-table-column>
        <el-table-column prop="sn" sortable="custom" label="序列号" width=auto show-overflow-tooltip></el-table-column>
        <el-table-column prop="manufacturer" label="生产厂商" width=auto show-overflow-tooltip></el-table-column>
        <el-table-column prop="note" label="备注" width="160" show-overflow-tooltip></el-table-column>
        <el-table-column prop="createUserName" label="创建者" width=auto show-overflow-tooltip></el-table-column>
        <el-table-column prop="createdAt" sortable="custom" label="创建时间" width=auto show-overflow-tooltip></el-table-column>
        <el-table-column prop="updatedAt" sortable="custom" label="更新时间" width="auto" show-overflow-tooltip></el-table-column>
        <el-table-column label="操作" width="150">
          <template slot-scope="scope" align="center">
            <el-link @click="$router.push({ name: 'appliance-equipment-create-or-update', query: { id: scope.row.id }})"
              icon="el-icon-edit" type="primary" class="m-r-sm">编辑
            </el-link>
            <el-link @click="handleDelete(scope.row)" type="danger" icon="el-icon-delete">删除</el-link>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog title="装置详细信息" center :visible.sync="showDetailsVisible" width="45%" :modal="true" lock-scroll :modal-append-to-body="false">
          <el-container>
            <el-form :model="equipmentInfo" status-icon ref="form" label-width="100px">
              <div class="el-col-24">
                <h3>装置基本信息：</h3>
                <hr/>
                <div class="el-col-12">
                  <el-form-item label="装置名称：" focus prop="name" >
                    <span name="name" type="text" >{{equipmentInfo.name}}</span>
                  </el-form-item>
                  <el-form-item label="装置类型：" prop="shieldType"  >
                    <span name="shieldType" type="text" >{{equipmentInfo.type}}</span>
                  </el-form-item>
                </div>
                <div class="el-col-12">
                  <el-form-item label="装置位置：" prop="signalType"  >
                    <span name="signalType" type="text" >{{equipmentInfo.location}}</span>
                  </el-form-item>
                  <el-form-item label="序列号：" prop="signalType"  >
                    <span name="signalType" type="text" >{{equipmentInfo.sn}}</span>
                  </el-form-item>
                </div>
              </div>
              <div class="el-col-24">
                <el-form-item label="生产厂商：">
                  <span name="isCustom" type="text" >{{equipmentInfo.manufacturer}}</span>
                </el-form-item>
              </div>
              <div class="el-col-24">
                <el-form-item label="备注：" prop="note" >
                    <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 5}" v-model.trim="equipmentInfo.note" readonly></el-input>
                  </el-form-item>
              </div>
              <div class="col-lg-24">
                <h3>装置其他信息：</h3>
                <hr/>
                <div class="el-col-12">
                  <el-form-item label="创建者：" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{equipmentInfo.createUserName}}</span>
                  </el-form-item>
                  <el-form-item label="创建时间" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{equipmentInfo.createdAt}}</span>
                  </el-form-item>
                </div>
                <div class="el-col-12">
                  <el-form-item label="更新者：" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{equipmentInfo.updateUserName}}</span>
                  </el-form-item>
                  <el-form-item label="更新时间" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{equipmentInfo.updatedAt}}</span>
                  </el-form-item>
                  <el-form-item label="更新次数" prop="note" >
                    <span name="note" :maxlength="500" type="textarea" >{{equipmentInfo.updateNum}}</span>
                  </el-form-item>
                </div>
              </div>
            </el-form>
          </el-container>
        </el-dialog>
    </div>
    <div class="row table-pagination m-t-xs m-r-xs">
      <el-pagination
      @size-change="fetchTableList(1)"
      @current-change="fetchTableList"
      @prev-click="fetchTableList(pagination.page - 1)"
      @next-click="fetchTableList(pagination.page + 1)"
      :page-sizes="[10, 20, 50, 100]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="pagination.totalCount"
      :page-size.sync="pageSize"
      :current-page="pagination.page">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import { formatTime } from '@/utils/tools'

export default {
  name: 'appliance-equipment',
  data: () => ({
    tableList: [],
    multipleSelection: [],
    condition: {},
    orderBy: {},
    equipmentSelection: [],
    deleteVisible: false,
    showDetailsVisible: false,
    equipmentInfo: {
      name: '',
      type: '',
      note: '',
      sn: '',
      location: '',
      manufacturer: '',
      createUserName: '',
      updateUserName: '',
      createdAt: '',
      updatedAt: '',
      updateNum: ''
    },
    device: '',
    interfaces: '',
    cable: ''
  }),
  computed: {
    ...mapGetters({ pagination: 'equipmentPagination' }),
    pageSize: {
      get () {
        return this.pagination.pageSize
      },
      set (pageSize) {
        this.updatePagination({ ...this.pagination, pageSize })
      }
    }
  },
  mounted () {
    this.fetchTableList()
    this.eventHub.$on('search:appliance', ({ name, condition }) => {
      if (name === 'equipment') {
        this.condition = { ...condition }
        this.fetchTableList(1)
      }
    })
  },
  methods: {
    ...mapMutations({ updatePagination: 'updateEquipmentPagination' }),
    handleDelete ({ id }) {
      this.searchRelation(id).then(() => {
        this.$confirm('此装置存在 ' + this.device + ' 个设备, ' + this.interfaces + ' 个接口和 ' + this.cable + ' 个线缆, 是否确认删除?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          this.deleteEquipment(id)
        })
      })
    },
    sortList ({ prop, order }) {
      prop = prop.replace(/([A-Z])/g, '_$1').toLowerCase()
      this.orderBy = {
        [prop]: order === 'descending' ? 'desc' : 'asc'
      }
      this.fetchTableList(this.pagination.page)
    },
    async searchRelation (id) {
      this.result = await this.$axios.get('appliance/equipment/child/' + id)
      this.device = this.result.msg.device
      this.interfaces = this.result.msg.interface
      this.cable = this.result.msg.cable
    },
    async deleteEquipment (id) {
      try {
        await this.$axios.delete(`appliance/equipment/${id}`)
        this.eventHub.$emit('change:equipment')
        await this.fetchTableList()
        this.$message.success('删除成功')
      } catch (error) {
        this.$message.warn('器材不存在')
      }
    },
    async copyTemplated () {
      if (this.multipleSelection.length < 1) {
        this.$message({
          type: 'warning',
          message: '您未选择任何装置'
        })
      } else {
        var equipmentSelection = this.multipleSelection.map(function (item) {
          return item['id']
        })
        try {
          await this.$axios.post(`appliance/equipment/templates`, {
            ids: equipmentSelection
          })
          this.$message.success('复刻成功')
        } catch (error) {
          this.$message.warn('复刻失败')
        }
      }
    },
    async fetchTableList (page = 1, condition = this.condition) {
      let result = await this.$axios.get('appliance/equipments', {
        params: {
          ...condition,
          orderBy: JSON.stringify(this.orderBy),
          pageSize: this.pagination.pageSize,
          page: page
        }
      })
      this.tableList = result.items.map(item => ({
        ...item,
        createdAt: formatTime(item.createdAt),
        updatedAt: formatTime(item.updatedAt)
      }))
      this.updatePagination(result.meta)
    },
    async showDetails (row, index) {
      try {
        let result = await this.$axios.get(`/appliance/equipment/${row.id}`)
        this.equipmentInfo = result
        this.equipmentInfo.createdAt = formatTime(result.createdAt)
        this.equipmentInfo.updatedAt = formatTime(result.updatedAt)
        this.showDetailsVisible = true
      } catch (error) {
        this.$message.error('没有找到该装置！')
      }
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    }
  }
}
</script>

<style scoped>
hr {
  border-top: 1px dotted rgb(47, 64, 80)
}
</style>
