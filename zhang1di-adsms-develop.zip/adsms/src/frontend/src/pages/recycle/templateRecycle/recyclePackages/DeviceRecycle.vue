<template>
    <div class="ibox-content">
        <div class="row">
            <div class="button-group">
                <el-button type="primary" @click.native="handleReset">恢复</el-button>
                <el-button type="primary" @click.native="handleDelete">彻底删除</el-button>
            </div>
        </div>
        <div class="row">
            <div class="table-responsive">
                 <el-table ref="multipleTable" :data="tableList" @selection-change="handleSelectionChange" height="400" border tooltip-effect="dark" style="width: 100%">
                    <el-table-column type="selection" width="55"></el-table-column>
                    <el-table-column prop="name" sortable label="设备名称" width="auto" show-overflow-tooltip></el-table-column>
                    <el-table-column prop="type" label="设备类型" width="auto" show-overflow-tooltip></el-table-column>
                    <el-table-column prop="location" sortable label="设备位置" width="auto" show-overflow-tooltip></el-table-column>
                    <el-table-column prop="sn" sortable label="序列号" width="auto" show-overflow-tooltip> </el-table-column>
                    <el-table-column  prop="manufacturer" label="生产厂商" width="auto" show-overflow-tooltip></el-table-column>
                    <el-table-column prop="note" sortable label="备注" width="160" show-overflow-tooltip></el-table-column>
                    <el-table-column prop="createUserName" sortable label="创建者" width="auto" show-overflow-tooltip></el-table-column>
                    <el-table-column  prop="createdAt" sortable label="创建时间" width="auto" show-overflow-tooltip></el-table-column>
                    <el-table-column prop="updatedAt" sortable label="更新时间" width="auto" show-overflow-tooltip></el-table-column>
                </el-table>
            </div>
        </div>
        <div class="table-pagination m-t-xs m-r-xs">
            <el-pagination
            @size-change="fetchTableList(1)"
            @current-change="fetchTableList"
            @prev-click="fetchTableList(deviceRecyclePagination.page - 1)"
            @next-click="fetchTableList(deviceRecyclePagination.page + 1)"
            :page-sizes="[10, 20, 50, 100]"
            layout="total, sizes, prev, pager, next, jumper"
            :total="deviceRecyclePagination.totalCount"
            :page-size.sync="pageSize"
            :current-page="deviceRecyclePagination.page">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import { formatTime } from '@/utils/tools'

export default {
  name: 'DeviceRecycle',
  data: () => ({
    tableList: [],
    condition: {},
    multipleSelection: []
  }),
  computed: {
    ...mapGetters([ 'deviceRecyclePagination' ]),
    pageSize: {
      get () {
        return this.deviceRecyclePagination.pageSize
      },
      set (pageSize) {
        this.updatedeviceRecyclePagination({ ...this.deviceRecyclePagination, pageSize })
      }
    }
  },
  mounted () {
    this.fetchTableList()
    this.eventHub.$on('template-search', ({ name, condition }) => {
      if (name === 'deviceRecycle') {
        this.condition = { ...condition }
        this.fetchTableList(1)
      }
    })
  },
  methods: {
    ...mapMutations(['updateDeviceRecyclePagination']),
    async fetchTableList (page = 1, condition = this.condition) {
      let result = await this.$axios.get('appliance/devices/templates/recycles', {
        params: {
          ...condition,
          pageSize: this.deviceRecyclePagination.pageSize,
          page: page
        }
      })
      this.tableList = result.items.map(item => ({
        ...item,
        createdAt: formatTime(item.createdAt),
        updatedAt: formatTime(item.updatedAt)
      }))
      this.updateDeviceRecyclePagination(result.meta)
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    handleReset () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要恢复的设备模板！')
      } else {
        this.$confirm('此操作将恢复该设备模板至设备模板列表, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var Selection = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.reset(Selection)
        }).catch()
      }
    },
    handleDelete () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要删除的设备模板！')
      } else {
        this.$confirm('此操作将永久删除该设备模板, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var Selection = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.delete(Selection)
        }).catch()
      }
    },
    async reset (Selection) {
      this.$axios.put('appliance/devices/templates/recycles', {
        ids: Selection
      }).then(() => {
        this.$message.success('已成功恢复设备模板！')
        this.fetchTableList()
      }).catch(error => {
        console.error(error)
        this.$message.warning('恢复设备模板失败！')
      })
    },
    async delete (Selection) {
      try {
        await this.$axios.delete('appliance/devices/recycles', {
          params: {
            ids: Selection
          }
        })
        this.$message.success('删除成功!')
        this.fetchTableList()
      } catch (error) {
        this.$message.warning('设备模板不存在!')
      }
    }
  }
}
</script>

<style scoped>
.table-responsive{
    margin-top: 10px;
}
</style>
