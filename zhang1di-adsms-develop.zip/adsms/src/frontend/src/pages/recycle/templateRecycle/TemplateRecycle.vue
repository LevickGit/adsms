<template>
    <div class="ibox-content">
        <div class="row">
          <div class="col-sm-4 m-b-xs">
            <div class="input-group align-left">
                <el-input class="handle-input m-r-sm" @clear="simpleOfSearch" v-model="searchKey" placeholder="名称/备注" clearable></el-input>
                <el-button type="primary" icon="el-icon-search" @click="simpleOfSearch">简单搜索</el-button>
            </div>
          </div>
        </div>
        <div class="tag"></div>
        <div class="ibox">
          <el-tabs type="border-card" @tab-click="tabChange" :value="activeName">
              <el-tab-pane label="装置" name="equipmentRecycle">
                <span slot="label">
                  <el-badge :value="equipmentRecycleTotalCount" :max="99" class="item">
                    <i class="el-icon-copy-document">装置模板</i>
                  </el-badge>
                </span>
                <EquipmentRecycle></EquipmentRecycle>
              </el-tab-pane>
              <el-tab-pane label="设备" name="deviceRecycle">
                <span slot="label">
                  <el-badge :value="deviceRecycleTotalCount" :max="99" class="item">
                    <i class="el-icon-receiving">设备模板</i>
                  </el-badge>
                </span>
                  <DeviceRecycle></DeviceRecycle>
              </el-tab-pane>
              <el-tab-pane label="接口" name="interfaceRecycle">
                <span slot="label">
                  <el-badge :value="interfaceRecycleTotalCount" :max="99" class="item">
                    <i class="el-icon-link">接口模板 </i>
                  </el-badge>
                </span>
                  <InterfaceRecycle></InterfaceRecycle>
              </el-tab-pane>
              <el-tab-pane label="线缆" name="cableRecycle">
                <span slot="label">
                  <el-badge :value="cableRecycleTotalCount" :max="99" class="item">
                    <i class="el-icon-connection">线缆模板</i>
                  </el-badge>
                </span>
                  <CableRecycle></CableRecycle>
              </el-tab-pane>
          </el-tabs>
      </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import EquipmentRecycle from './recyclePackages/EquipmentRecycle'
import DeviceRecycle from './recyclePackages/DeviceRecycle'
import InterfaceRecycle from './recyclePackages/InterfaceRecycle'
import CableRecycle from './recyclePackages/CableRecycle'

export default {
  name: 'ApplianceRecycle',
  data: () => ({
    searchKey: ''
  }),
  components: { EquipmentRecycle, DeviceRecycle, InterfaceRecycle, CableRecycle },
  computed: {
    ...mapGetters(['equipmentRecycleTotalCount', 'deviceRecycleTotalCount', 'interfaceRecycleTotalCount', 'cableRecycleTotalCount']),
    activeName () {
      return this.$route.query.tab || 'equipmentRecycle'
    }
  },
  methods: {
    simpleOfSearch () {
      // this.eventHub.$emit('template-search', this.condition)
      this.eventHub.$emit('template-search', {
        name: this.activeName,
        type: 'simple',
        condition: {
          searchKey: this.searchKey
        }
      })
    },
    tabChange ({ name }) {
      this.$router.push({
        name: this.$route.name,
        query: {
          ...this.$route.query,
          tab: name
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.ibox{
    margin-top: 10px;
}
.item {
  margin: 10px 40px 10px 20px;
}
</style>
