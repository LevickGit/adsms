<template>
    <main-layout>
        <div class="ibox-content">
            <el-tabs type="border-card">
                <el-tab-pane>
                    <span slot="label"><i class="el-icon-s-custom"></i> 用户 </span>
                    <UserRecycle></UserRecycle>
                </el-tab-pane>
                <el-tab-pane label="器材">
                    <span slot="label"><i class="el-icon-s-cooperation"></i> 器材</span>
                    <ApplianceRecycle></ApplianceRecycle>
                </el-tab-pane>
                <el-tab-pane label="模板">
                    <span slot="label"><i class="el-icon-s-order"></i>  模板  </span>
                    <TemplateRecycle></TemplateRecycle>
                </el-tab-pane>
            </el-tabs>
        </div>
    </main-layout>
</template>

<script>
import UserRecycle from './userRecycle/UserRecycle.vue'
import ApplianceRecycle from './applianceRecycle/ApplianceRecycle.vue'
import TemplateRecycle from './templateRecycle/TemplateRecycle.vue'
export default {
  name: 'Recycle',
  components: { UserRecycle, ApplianceRecycle, TemplateRecycle }
}

</script>
