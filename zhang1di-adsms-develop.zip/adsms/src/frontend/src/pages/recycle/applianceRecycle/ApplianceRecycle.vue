<template>
    <div class="ibox-content">
        <div class="row">
          <div class="col-sm-4 m-b-xs">
            <div class="input-group align-left">
                <el-input class="handle-input m-r-sm" @clear="simpleSearch" v-model="searchKey" placeholder="名称/备注" clearable></el-input>
                <el-button type="primary" icon="el-icon-search" @click="simpleSearch">简单搜索</el-button>
            </div>
          </div>
        </div>
        <div class="tag"></div>
        <div class="ibox">
          <el-tabs type="border-card" @tab-click="tabChange" :value="activeName">
              <el-tab-pane label="装置" name="equipmentRecycle">
                <span slot="label">
                  <el-badge :value="equipmentOfRecycleTotalCount" :max="99" class="item">
                    <i class="el-icon-copy-document">装置</i>
                  </el-badge>
                </span>
                <EquipmentRecycle></EquipmentRecycle>
              </el-tab-pane>
              <el-tab-pane label="设备" name="deviceRecycle">
                <span slot="label">
                  <el-badge :value="deviceOfRecycleTotalCount" :max="99" class="item">
                    <i class="el-icon-receiving">设备</i>
                  </el-badge>
                </span>
                  <DeviceRecycle></DeviceRecycle>
              </el-tab-pane>
              <el-tab-pane label="接口" name="interfaceRecycle">
                <span slot="label">
                  <el-badge :value="interfaceOfRecycleTotalCount" :max="99" class="item">
                    <i class="el-icon-link">接口</i>
                  </el-badge>
                </span>
                  <InterfaceRecycle></InterfaceRecycle>
              </el-tab-pane>
              <el-tab-pane label="线缆" name="cableRecycle">
                <span slot="label">
                  <el-badge :value="cableOfRecycleTotalCount" :max="99" class="item">
                    <i class="el-icon-connection">线缆</i>
                  </el-badge>
                </span>
                  <CableRecycle></CableRecycle>
              </el-tab-pane>
          </el-tabs>
      </div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import EquipmentRecycle from './recyclePackage/EquipmentRecycle'
import DeviceRecycle from './recyclePackage/DeviceRecycle'
import InterfaceRecycle from './recyclePackage/InterfaceRecycle'
import CableRecycle from './recyclePackage/CableRecycle'

export default {
  name: 'ApplianceRecycle',
  data: () => ({
    searchKey: ''
  }),
  components: { EquipmentRecycle, DeviceRecycle, InterfaceRecycle, CableRecycle },
  computed: {
    ...mapGetters(['equipmentOfRecycleTotalCount', 'deviceOfRecycleTotalCount', 'interfaceOfRecycleTotalCount', 'cableOfRecycleTotalCount']),
    activeName () {
      return this.$route.query.tab || 'equipmentRecycle'
    }
  },
  methods: {
    simpleSearch () {
      //  this.eventHub.$emit('app-search', this.condition)
      this.eventHub.$emit('app-search', {
        name: this.activeName,
        type: 'simple',
        condition: {
          searchKey: this.searchKey
        }
      })
    },
    tabChange ({ name }) {
      this.$router.push({
        name: this.$route.name,
        query: {
          ...this.$route.query,
          tab: name
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.ibox{
    margin-top: 10px;
}
.item {
  margin: 10px 40px 10px 20px;
}
</style>
