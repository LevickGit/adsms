<template>
    <div class="UserRecycle">
        <div class="ibox-content">
            <div class="row">
              <div class="col-sm-4">
                <div class="input-group align-left">
                  <el-input class="handle-input m-r-sm" v-model="condition.searchKey" clearable placeholder="用户名/邮箱"></el-input>
                  <el-button @click="fetchUserList()" type="primary" icon="el-icon-search">用户搜索</el-button>
                </div>
              </div>
            </div>
            <div class="row">
                <div class="button-group">
                    <el-button type="primary" @click.native="handleResetUser">恢复</el-button>
                    <el-button type="primary" @click.native="handleDelete">彻底删除</el-button>
                </div>
            </div>
            <div class="box">
                <div class="table-responsive">
                    <el-table :data="userList" tooltip-effect="light" style="width: 100%" :default-sort = "{prop: 'username', order: 'ascending'}"
                        @selection-change="handleSelectionChange">
                        <el-table-column type="selection" width="55"></el-table-column>
                        <el-table-column prop="username" sortable label="姓名" width="120"></el-table-column>
                        <el-table-column prop="email" label="邮箱" width="120"></el-table-column>
                        <el-table-column prop="department" sortable label="部门" show-overflow-tooltip></el-table-column>
                        <el-table-column prop="position" sortable label="职位" show-overflow-tooltip></el-table-column>
                        <el-table-column prop="phone" label="电话" show-overflow-tooltip></el-table-column>
                        <el-table-column prop="role" sortable label="权限" show-overflow-tooltip></el-table-column>
                        <el-table-column prop="loginNum" sortable label="登录次数" show-overflow-tooltip></el-table-column>
                    </el-table>
                </div>
                <div class="row table-pagination m-t-xs m-r-xs">
                    <el-pagination
                        @size-change="fetchUserList()"
                        @current-change="fetchUserList"
                        @prev-click="fetchUserList(pagination.page - 1)"
                        @next-click="fetchUserList(pagination.page + 1)"
                        :page-sizes="[10, 20, 50, 100]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="pagination.totalCount"
                        :page-size.sync="pagination.pageSize"
                        :current-page="pagination.page">
                    </el-pagination>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  name: 'UserRecycle',
  data: () => ({
    userList: [],
    pagination: {
      page: 1,
      pageCount: 0,
      pageSize: 10,
      totalCount: 0
    },
    condition: {
      searchKey: ''
    },
    multipleSelection: []
  }),
  mounted () {
    this.fetchUserList()
  },
  methods: {
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    handleResetUser () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要恢复的用户！')
      } else {
        this.$confirm('此操作将恢复该用户至用户列表, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var userSelection = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.resetUser(userSelection).then(() => {
            this.$message({
              type: 'success',
              message: '恢复用户成功!'
            })
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消恢复用户！'
          })
        })
      }
    },
    handleDelete () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要删除的用户！')
      } else {
        this.$confirm('此操作将永久删除该用户, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var userInSelection = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.deleteUser(userInSelection)
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      }
    },
    async fetchUserList (page = 1) {
      let result = await this.$axios({
        url: 'account/users/recycles',
        method: 'get',
        params: {
          ...this.condition,
          page: page,
          pageSize: this.pagination.pageSize
        }
      })
      this.userList = this.formatUserList(result.items)
      this.pagination = result.meta
    },
    async resetUser (userSelection) {
      this.$axios.put('account/users/recycles', {
        ids: userSelection
      }).then(() => {
        this.$message.success('已成功恢复用户！')
        this.fetchUserList()
      }).catch(error => {
        console.error(error)
        this.$message.warning('恢复用户失败！')
      })
    },
    async deleteUser (userInSelection) {
      try {
        await this.$axios.delete('account/users/recycles', {
          params: {
            ids: userInSelection
          }
        })
        this.$message.success('删除成功')
        this.fetchUserList()
      } catch (error) {
        this.$message.warning('用户不存在')
      }
    },
    formatUserList (userList) {
      return userList.map(user => ({
        ...user,
        role: user.superuser ? '超级管理员' : user.admin ? '管理员' : '普通用户'
      }))
    }
  }
}
</script>

<style scoped>
.button-group{
    margin: 10px 0 0 14px;
}

.box{
    margin-top: 10px;
}
</style>
