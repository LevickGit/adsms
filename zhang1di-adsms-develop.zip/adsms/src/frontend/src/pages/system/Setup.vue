<template>
  <main-layout>
    <div class="row">
      <div class="col-lg-12">
        <div class="setupBox">
          <el-form label-width="200px">
            <h3>器材信息设置</h3>
            <hr/>
            <el-form-item label="线缆的屏蔽类型">
              <div class="tag-area">
                <el-input
                  class="input-new-tag"
                  v-if="shieldTypeInputVisible"
                  v-model="shieldTypeInputValue"
                  ref="shieldTypeSaveTagInput"
                  size="small"
                  @keyup.enter.native="shieldTypeHandleInputConfirm"
                  @blur="shieldTypeHandleInputConfirm"
                ></el-input>
                <el-button v-else class="button-new-tag" size="mini" @click="shieldTypeShowInput">添加</el-button>
                <el-tag
                  :key="tag"
                  v-for="tag in systemShieldTypes"
                  closable
                  :disable-transitions="false"
                  @close="shieldTypeHandleClose(tag)"
                  @change="fetchSystemInformation"
                >{{tag}}</el-tag>
              </div>
            </el-form-item>
            <el-form-item label="接口的接头类型">
              <div class="tag-area">
                <el-input
                  class="input-new-tag"
                  v-if="spliceTypeInputVisible"
                  v-model="spliceTypeInputValue"
                  ref="spliceTypeSaveTagInput"
                  size="small"
                  @keyup.enter.native="spliceTypeHandleInputConfirm"
                  @blur="spliceTypeHandleInputConfirm"
                ></el-input>
                <el-button
                  v-else
                  class="button-new-tag"
                  size="small"
                  @click="spliceTypeShowInput"
                >添加</el-button>
                <el-tag
                  :key="tag"
                  v-for="tag in systemSpliceTypes"
                  closable
                  :disable-transitions="false"
                  @close="spliceTypeHandleClose(tag)"
                >{{tag}}</el-tag>
              </div>
            </el-form-item>
            <el-form-item label="接口的电气接口协议">
              <div class="tag-area">
                <el-input
                  class="input-new-tag"
                  v-if="interfaceProtocolInputVisible"
                  v-model="interfaceProtocolInputValue"
                  ref="interfaceProtocolSaveTagInput"
                  size="small"
                  @keyup.enter.native="interfaceProtocolHandleInputConfirm"
                  @blur="interfaceProtocolHandleInputConfirm"
                ></el-input>
                <el-button
                  v-else
                  class="button-new-tag"
                  size="small"
                  @click="interfaceProtocolShowInput"
                >添加</el-button>
                <el-tag
                  :key="tag"
                  v-for="tag in systemInterfaceProtocol"
                  closable
                  :disable-transitions="false"
                  @close="interfaceProtocolHandleClose(tag)"
                >{{tag}}</el-tag>
              </div>
            </el-form-item>
            <h3>用户信息设置</h3>
            <hr/>
            <el-form-item label="用户职位">
              <div class="tag-area">
                <el-input
                  class="input-new-tag"
                  v-if="positionInputVisible"
                  v-model="positionInputValue"
                  ref="positionSaveTagInput"
                  size="small"
                  @keyup.enter.native="positionHandleInputConfirm"
                  @blur="positionHandleInputConfirm"
                ></el-input>
                <el-button v-else class="button-new-tag" size="small" @click="positionShowInput">添加</el-button>
                <el-tag
                  :key="tag"
                  v-for="tag in systemPositions"
                  closable
                  :disable-transitions="false"
                  @close="positionHandleClose(tag)"
                >{{tag}}</el-tag>
              </div>
            </el-form-item>
            <el-form-item label="用户所属部门">
              <div class="tag-area">
                <el-input
                  class="input-new-tag"
                  v-if="departmentInputVisible"
                  v-model="departmentInputValue"
                  ref="departmentSaveTagInput"
                  size="small"
                  @keyup.enter.native="departmentHandleInputConfirm"
                  @blur="departmentHandleInputConfirm"
                ></el-input>
                <el-button
                  v-else
                  class="button-new-tag"
                  size="small"
                  @click="departmentShowInput"
                >添加</el-button>
                <el-tag
                  :key="tag"
                  v-for="tag in systemDepartments"
                  closable
                  :disable-transitions="false"
                  @close="departmentHandleClose(tag)"
                >{{tag}}</el-tag>
              </div>
            </el-form-item>
          </el-form>
        </div>
      </div>
    </div>
  </main-layout>
</template>

<script>
import { mapMutations, mapGetters, mapActions } from 'vuex'
export default {
  name: 'system-setup',
  data: () => ({
    departmentInputVisible: false,
    positionInputVisible: false,
    shieldTypeInputVisible: false,
    spliceTypeInputVisible: false,
    interfaceProtocolInputVisible: false,
    departmentInputValue: '',
    positionInputValue: '',
    shieldTypeInputValue: '',
    spliceTypeInputValue: '',
    interfaceProtocolInputValue: '',
    deleteState: []
  }),
  computed: {
    ...mapGetters(['systemInfo', 'systemDepartments', 'systemPositions', 'systemShieldTypes', 'systemSpliceTypes', 'systemInterfaceProtocol'])
  },
  methods: {
    ...mapActions(['fetchSystemInformation']),
    ...mapMutations(['updateSystemInfo']),
    async fetchSystemInformation () {
      let result = await this.$axios.get('system/settings')
      this.updateSystemInfo(result)
    },
    async departmentHandleClose (tag) {
      this.$confirm('此操作将永久删除该信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        center: true
      }).then(() => {
        this.deleteDepartment(tag)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    positionHandleClose (tag) {
      this.$confirm('此操作将永久删除该信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        center: true
      }).then(() => {
        this.deletePosition(tag)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    interfaceProtocolHandleClose (tag) {
      this.$confirm('此操作将永久删除该信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        center: true
      }).then(() => {
        this.deleteInterfaceProtocol(tag)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    spliceTypeHandleClose (tag) {
      this.$confirm('此操作将永久删除该信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        center: true
      }).then(() => {
        this.deleteSpliceType(tag)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    shieldTypeHandleClose (tag) {
      this.$confirm('此操作将永久删除该信息, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
        center: true
      }).then(() => {
        this.deleteShieldType(tag)
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    async deleteDepartment (tag) {
      var deleteResult = await this.$axios.delete('system/settings', {
        params: {
          name: 'departments',
          value: tag
        }
      })
      if (deleteResult.ok === true) {
        this.$message({
          type: 'success',
          message: '删除成功'
        })
        this.systemDepartments.splice(this.systemDepartments.indexOf(tag), 1)
      } else if (deleteResult.ok === false) {
        this.$message({
          type: 'error',
          message: '删除失败，当前项目已被占用，无法删除'
        })
      }
    },
    async deletePosition (tag) {
      let deleteResult = await this.$axios.delete('system/settings', {
        params: {
          name: 'positions',
          value: tag
        }
      })
      if (deleteResult.ok === true) {
        this.$message({
          type: 'success',
          message: '删除成功'
        })
        this.systemPositions.splice(this.systemPositions.indexOf(tag), 1)
      } else if (deleteResult.ok === false) {
        this.$message({
          type: 'error',
          message: '删除失败，当前项目已被占用，无法删除'
        })
      }
    },
    async deleteShieldType (tag) {
      let deleteResult = await this.$axios.delete('system/settings', {
        params: {
          name: 'shieldTypes',
          value: tag
        }
      })
      if (deleteResult.ok === true) {
        this.$message({
          type: 'success',
          message: '删除成功'
        })
        this.systemShieldTypes.splice(this.systemShieldTypes.indexOf(tag), 1)
      } else if (deleteResult.ok === false) {
        this.$message({
          type: 'error',
          message: '删除失败，当前项目已被占用，无法删除'
        })
      }
    },
    async deleteSpliceType (tag) {
      let deleteResult = await this.$axios.delete('system/settings', {
        params: {
          name: 'spliceTypes',
          value: tag
        }
      })
      if (deleteResult.ok === true) {
        this.$message({
          type: 'success',
          message: '删除成功'
        })
        this.systemSpliceTypes.splice(this.systemSpliceTypes.indexOf(tag), 1)
      } else if (deleteResult.ok === false) {
        this.$message({
          type: 'error',
          message: '删除失败，当前项目已被占用，无法删除'
        })
      }
    },
    async deleteInterfaceProtocol (tag) {
      let deleteResult = await this.$axios.delete('system/settings', {
        params: {
          name: 'interfaceProtocol',
          value: tag
        }
      })
      if (deleteResult.ok === true) {
        this.$message({
          type: 'success',
          message: '删除成功'
        })
        this.systemInterfaceProtocol.splice(this.systemInterfaceProtocol.indexOf(tag), 1)
      } else if (deleteResult.ok === false) {
        this.$message({
          type: 'error',
          message: '删除失败，当前项目已被占用，无法删除'
        })
      }
    },
    departmentShowInput () {
      this.departmentInputVisible = true
      this.$nextTick(_ => {
        this.$refs.departmentSaveTagInput.$refs.input.focus()
      })
    },
    positionShowInput () {
      this.positionInputVisible = true
      this.$nextTick(_ => {
        this.$refs.positionSaveTagInput.$refs.input.focus()
      })
    },
    shieldTypeShowInput () {
      this.shieldTypeInputVisible = true
      this.$nextTick(_ => {
        this.$refs.shieldTypeSaveTagInput.$refs.input.focus()
      })
    },
    spliceTypeShowInput () {
      this.spliceTypeInputVisible = true
      this.$nextTick(_ => {
        this.$refs.spliceTypeSaveTagInput.$refs.input.focus()
      })
    },
    interfaceProtocolShowInput () {
      this.interfaceProtocolInputVisible = true
      this.$nextTick(_ => {
        this.$refs.interfaceProtocolSaveTagInput.$refs.input.focus()
      })
    },
    async departmentHandleInputConfirm () {
      let departmentInputValue = this.departmentInputValue
      if (departmentInputValue) {
        this.systemDepartments.push(this.departmentInputValue)
        await this.$axios.put('system/settings', {
          name: 'departments',
          value: this.departmentInputValue
        })
      }
      this.departmentInputVisible = false
      this.departmentInputValue = ''
    },
    async positionHandleInputConfirm () {
      let positionInputValue = this.positionInputValue
      if (positionInputValue) {
        this.systemPositions.push(this.positionInputValue)
        await this.$axios.put('system/settings', {
          name: 'positions',
          value: this.positionInputValue
        })
      }
      this.positionInputValue = ''
      this.positionInputVisible = false
    },
    async shieldTypeHandleInputConfirm () {
      let shieldTypeInputValue = this.shieldTypeInputValue
      if (shieldTypeInputValue) {
        this.systemShieldTypes.push(this.shieldTypeInputValue)
        await this.$axios.put('system/settings', {
          name: 'shieldTypes',
          value: this.shieldTypeInputValue
        })
      }
      this.shieldTypeInputValue = ''
      this.shieldTypeInputVisible = false
    },
    async spliceTypeHandleInputConfirm () {
      let spliceTypeInputValue = this.spliceTypeInputValue
      if (spliceTypeInputValue) {
        this.systemSpliceTypes.push(this.spliceTypeInputValue)
        await this.$axios.put('system/settings', {
          name: 'spliceTypes',
          value: this.spliceTypeInputValue
        })
      }
      this.spliceTypeInputValue = ''
      this.spliceTypeInputVisible = false
    },
    async interfaceProtocolHandleInputConfirm () {
      let interfaceProtocolInputValue = this.interfaceProtocolInputValue
      if (interfaceProtocolInputValue) {
        this.systemInterfaceProtocol.push(this.interfaceProtocolInputValue)
        await this.$axios.put('system/settings', {
          name: 'interfaceProtocol',
          value: this.interfaceProtocolInputValue
        })
      }
      this.interfaceProtocolInputValue = ''
      this.interfaceProtocolInputVisible = false
    }
  }
}
</script>

<style>
  .tag-area {
    max-height: 105px;
    overflow-y: scroll;
    border: 1px solid rgba(171, 171, 171, 0.6);
    background-color: #fff;
  }
  .setupBox {
    width: 60%;
  }
  .el-tag + .el-tag {
    margin-left: 5px;
  }
  .button-new-tag {
    margin-left: 5px;
    margin-right: 10px;
    height: 25px;
    line-height: 25px;
    padding-top: 0;
    padding-bottom: 0;
  }
  .input-new-tag {
    width: 90px;
    margin-right: 10px;
    vertical-align: bottom;
  }
  hr {
    color: blueviolet;
    border-top: 1px dashed rgb(47, 64, 80);
  }
</style>
