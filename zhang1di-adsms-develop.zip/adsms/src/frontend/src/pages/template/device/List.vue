<template>
    <div class="appliance-device">
        <div class="row">
            <div class="col-sm-8 m-b-xs">
              <el-button type="primary" icon="el-icon-check" @click.native="handleVerify">审核通过</el-button>
              <el-button type="danger" icon="el-icon-delete" @click.native="handleDelete">删除</el-button>
            </div>
        </div>
        <div class="table-responsive">
          <el-table ref="multipleTable" :data="templateList" @selection-change="handleSelectionChange" height="400" border tooltip-effect="dark" style="width: 100%">
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="verified" type="text" label="审核状态" width="auto" sortable show-overflow-tooltip></el-table-column>
            <el-table-column prop="name" sortable label="设备名称" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="type" label="设备类型" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="location" sortable label="设备位置" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="sn" sortable label="序列号" width="auto" show-overflow-tooltip> </el-table-column>
            <el-table-column  prop="manufacturer" label="生产厂商" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="note" sortable label="备注" width="160" show-overflow-tooltip></el-table-column>
            <el-table-column prop="createUserName" sortable label="创建者" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column  prop="createdAt" sortable label="创建时间" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column prop="updatedAt" sortable label="更新时间" width="auto" show-overflow-tooltip></el-table-column>
            <el-table-column label="操作" width="80">
              <template slot-scope="scope">
                <el-link @click="$router.push({ name: 'template-device-create-or-update', query: { id: scope.row.id }})"
                  icon="el-icon-edit" type="primary" class="m-r-sm">编辑
                </el-link>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="row table-pagination m-t-xs m-r-xs">
            <el-pagination
              @size-change="fetchTableList(1)"
              @current-change="fetchTableList"
              @prev-click="fetchTableList(deviceTemplatesPagination.page - 1)"
              @next-click="fetchTableList(deviceTemplatesPagination.page + 1)"
              :page-sizes="[10, 20, 50, 100]"
              layout="total, sizes, prev, pager, next, jumper"
              :total="deviceTemplatesPagination.totalCount"
              :page-size.sync="pageSize"
              :current-page="deviceTemplatesPagination.page">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import { formatTime } from '@/utils/tools'

export default {
  name: 'appliance-deviceTemplates',
  data: () => ({
    templateList: [],
    multipleSelection: [],
    condition: {}
  }),
  computed: {
    ...mapGetters(['deviceTemplatesPagination']),
    pageSize: {
      get () {
        return this.deviceTemplatesPagination.pageSize
      },
      set (pageSize) {
        this.updateDeviceTemplatePagination({ ...this.deviceTemplatesPagination, pageSize })
      }
    }
  },
  mounted () {
    this.fetchTableList()
    this.eventHub.$on('appliance-search', ({ name, condition }) => {
      if (name === 'deviceTemplate') {
        this.condition = { ...condition }
        this.fetchTableList(1)
      }
    })
  },
  methods: {
    ...mapMutations([ 'updateDeviceTemplatePagination' ]),
    handleDelete () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要删除的设备模板！')
      } else {
        this.$confirm('此操作将永远删除该设备模板, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var deviceId = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.deleteDeviceTemplate(deviceId)
        }).catch()
      }
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    handleVerify () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要审核的设备模板！')
      } else {
        this.$confirm('您将审核通过该设备模板, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var DeviceTemplatesSelections = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.verifyDeviceTemplates(DeviceTemplatesSelections)
        }).catch()
      }
    },
    async deleteDeviceTemplate () {
      try {
        var templatesSelection = this.multipleSelection.map(function (item) {
          return item['id']
        })
        await this.$axios.delete(`appliance/device/templates`, {
          params: {
            ids: templatesSelection
          }
        })
        this.deleteVisible = false
        this.$message.success('删除成功！')
        this.fetchTableList()
      } catch (error) {
        this.$message.warn('器材不存在!')
      }
    },
    async verifyDeviceTemplates () {
      try {
        var deviceTemplatesSelections = this.multipleSelection.map(function (item) {
          return item['id']
        })
        await this.$axios.put(`appliance/device/templates`, {
          ids: deviceTemplatesSelections
        })
        this.updateVisible = false
        this.$message.success('审核成功!')
        this.fetchTableList()
      } catch (error) {
        this.$message.warn('器材不存在!')
      }
    },
    async fetchTableList (page = 1, condition = this.condition) {
      let result = await this.$axios.get('/appliance/device/templates', {
        params: {
          ...condition,
          page: page,
          pageSize: this.deviceTemplatesPagination.pageSize
        }
      })
      this.templateList = result.items.map(item => ({
        ...item,
        verified: item.verifyUserName ? '已审核' : '未审核',
        createdAt: formatTime(item.createdAt),
        updatedAt: formatTime(item.updatedAt)
      }))
      this.updateDeviceTemplatePagination(result.meta)
    }
  }
}
</script>
