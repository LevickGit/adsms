<template>
  <main-layout>
    <div class="row">
      <div class="col-lg-12">
        <div class="ibox">
          <div class="ibox-title">
            <h5>器材模板列表</h5>
          </div>
          <div class="ibox-content">
            <div class="row">
              <div class="col-sm-4 m-b-xs">
                <div class="input-group align-left">
                  <el-input class="handle-input m-r-sm" clearable @clear="simpleSearch" v-model="searchKey"  placeholder="名称/备注"></el-input>
                  <el-button type="primary" icon="el-icon-search" @click="simpleSearch">简单搜索</el-button>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="complexSearchPages col-sm-8 m-b-xs">
              </div>
            </div>
            <div class="tag"></div>
          </div>
          <div class="ibox-content">
            <el-tabs type="border-card" @tab-click="tabChange" :value="activeName">
              <el-tab-pane label="装置"  name="equipmentTemplate">
                <span slot="label">
                  <el-badge :value="equipmentTemplatesTotalCount" :max="99" class="item">
                    <i class="el-icon-copy-document"> 装置</i>
                  </el-badge>
                </span>
                <Equipment-list ref="myequipment"></Equipment-list>
              </el-tab-pane>
              <el-tab-pane label="设备"  name="deviceTemplate">
                <span slot="label">
                  <el-badge :value="deviceTemplatesTotalCount" :max="99" class="item">
                    <i class="el-icon-receiving"> 设备</i>
                  </el-badge>
                </span>
                <Device-list ref="mydevice"></Device-list>
              </el-tab-pane>
              <el-tab-pane label="接口"  name="interfaceTemplate">
                <span slot="label" name="third" label="接口">
                  <el-badge :value="interfaceTemplatesTotalCount" :max="99" class="item">
                    <i class="el-icon-link"> 接口</i>
                  </el-badge>
                </span>
                <Interface-list ref="myinterface"></Interface-list>
              </el-tab-pane>
              <el-tab-pane label="线缆"  name="cableTemplate">
                <span slot="label" name="fourth" label="线缆">
                  <el-badge :value="cableTemplatesTotalCount" :max="99" class="item">
                    <i class="el-icon-connection"> 线缆</i>
                  </el-badge>
                </span>
                <Cable-list ref="mycable"></Cable-list>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </div>
    </div>
  </main-layout>
</template>

<script>
import { mapGetters } from 'vuex'
import CableList from './cable/List.vue'
import DeviceList from './device/List.vue'
import EquipmentList from './equipment/List.vue'
import InterfaceList from './interface/List.vue'

export default {
  name: 'appliance-equipmentTemplates',
  data: () => ({
    value: '',
    input: '',
    searchKey: '',
    equipmentTemplates: {
      name: '',
      sn: '',
      type: '',
      position: '',
      manufacturer: '',
      createUser: '',
      createTime: '',
      updateTime: ''
    },
    deviceTemplates: {
      name: '',
      sn: '',
      type: '',
      position: '',
      manufacturer: '',
      createUser: '',
      system: '',
      createTime: '',
      updateTime: ''
    },
    InterfaceTemplates: {
      name: '',
      sn: '',
      type: '',
      position: '',
      agreement: '',
      createUser: '',
      createTime: '',
      updateTime: ''
    },
    cableTemplates: {
      frontEquipment: '',
      endEquipment: '',
      frontDevice: '',
      endDevice: '',
      frontInterface: '',
      endInterface: '',
      name: '',
      signalType: '',
      sheildType: '',
      createTime: '',
      updateTime: ''
    }
  }),
  computed: {
    ...mapGetters(['equipmentTemplatesTotalCount', 'deviceTemplatesTotalCount', 'interfaceTemplatesTotalCount', 'cableTemplatesTotalCount']),
    activeName () {
      return this.$route.query.tab || 'equipmentTemplate'
    }
  },
  components: { CableList, DeviceList, EquipmentList, InterfaceList },
  methods: {
    simpleSearch () {
      this.eventHub.$emit('appliance-search', {
        name: this.activeName,
        type: 'simple',
        condition: {
          searchKey: this.searchKey
        }
      })
    },
    tabChange ({ name }) {
      this.$router.push({
        name: this.$route.name,
        query: {
          ...this.$route.query,
          tab: name
        }
      })
    }
  }
}
</script>

<style lang="scss">
.handle-select {
  width: calc((100% - 20px) / 2);
}
.handle-input {
  width: calc(100% - 83px);
}

.align-between {
  justify-content: space-between;
}

.align-left {
  justify-content: flex-start;
}

.range-group{
  margin-right:-150px;
  padding-right:0;
}

.item {
  margin: 10px 40px 10px 20px;
}

.complexSearchPages{
  margin-top: 5px;
}
</style>
