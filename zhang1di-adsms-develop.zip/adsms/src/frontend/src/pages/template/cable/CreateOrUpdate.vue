<template>
  <main-layout :crumbs="[{
    title: '模板管理',
    path: '/template?tab=cable'
  }, {
    title: $route.query.id ? '更新线缆模板' : '新增线缆模板'
  }]">
    <div class="container-fluid">
      <div class="row">
        <div class="el-col-10 el-col-offset-7 ">
          <h2 class="text-center">线缆模板信息录入</h2>
          <el-form :model="cableTemplateInfo"  status-icon ref="form" label-width="100px" size="medium">
            <el-form-item label="线缆名称："  focus prop="name" >
              <el-input name="name" type="text" v-model.trim="cableTemplateInfo.name" autocomplete="on"></el-input>
            </el-form-item>
            <el-form-item label="信号类型：" prop="signalType"  >
              <el-input name="signalType" type="text" v-model.trim="cableTemplateInfo.signalType" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="屏蔽类型：" prop="shieldType"  >
              <el-input name="shieldType" type="text" v-model.trim="cableTemplateInfo.shieldType"></el-input>
            </el-form-item>
            <el-form-item label="是否定制：">
              <el-radio-group name="isCustom" v-model="cableTemplateInfo.isCustom">
                <el-radio :label="true">是</el-radio>
                <el-radio :label="false">否</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="定制参数：" v-if="cableTemplateInfo.isCustom === true">
              <el-input
                type="textarea"
                :row="3"
                aria-placeholder="请输入定制参数"
                v-model="cableTemplateInfo.parameterList"
                >
              </el-input>
            </el-form-item>
            <el-form-item label="起始接口：" prop="note">
              <el-cascader
                class="full-width"
                v-model="cableTemplateInfo.startParent"
                placeholder="设备名/装置名/接口名"
                :options="interfaceMeta"
                filterable>
              </el-cascader>
            </el-form-item>
            <el-form-item label="终止接口：" prop="note">
              <el-cascader
                class="full-width"
                v-model="cableTemplateInfo.endParent"
                placeholder="设备名/装置名/接口名"
                :options="interfaceMeta"
                filterable>
              </el-cascader>
            </el-form-item>
            <el-form-item label="备注：" prop="note" >
              <el-input name="note" :show-word-limit="true" :maxlength="100" type="textarea" :autosize="{ minRows: 2, maxRows: 5}" v-model.trim="cableTemplateInfo.note"></el-input>
            </el-form-item>
            <el-form-item class="text-center">
              <el-button size="large" type="primary" @click="submit">提交</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
    </div>
  </main-layout>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'cableTemplatesManagement',
  data: () => ({
    keyword: '',
    cableTemplateInfo: {
      name: '',
      signalType: '',
      shieldType: '',
      note: '',
      isCustom: true,
      parameterList: '',
      startParent: '',
      endParent: ''
    },
    templateInfo: [],
    flag: false
  }),
  computed: {
    ...mapGetters(['interfaceMeta'])
  },
  created () {
    if (this.$route.query.id) {
      this.fetchCable(this.$route.query.id)
    }
  },
  methods: {
    submit () {
      this.$refs.form.validate().then(() => {
        let id = this.$route.query.id
        let params = this.formatRequestParams()
        id ? this.$axios.put(`appliance/cable/template/${id}`, params).then(response => {
          if (response.ok) {
            this.$message.success('更新线缆模板成功')
            this.$router.push({
              name: 'template',
              query: { tab: 'cableTemplate' }
            })
          } else {
            this.$message.error(response.msg)
          }
        }) : this.$axios.post('appliance/cable/template', params).then(response => {
          if (response.ok) {
            this.$message.success('创建线缆模板成功')
            this.$router.push({
              name: 'template',
              query: { tab: 'cableTemplate' }
            })
          } else {
            this.$message.error(response.msg)
          }
        })
      })
    },
    fetchCable (id) {
      this.$axios.get(`appliance/cable/${id}`).then(cable => {
        this.cableTemplateInfo.name = cable.name
        this.cableTemplateInfo.signalType = cable.signalType
        this.cableTemplateInfo.shieldType = cable.shieldType
        this.cableTemplateInfo.note = cable.note
        this.cableTemplateInfo.isCustom = cable.isCustom
        this.cableTemplateInfo.parameterList = cable.parameterList
        this.cableTemplateInfo.startParent = [
          cable.startEquipment.id,
          cable.startDevice.id,
          cable.startInterface.id
        ]
        this.cableTemplateInfo.endParent = [
          cable.endEquipment.id,
          cable.endDevice.id,
          cable.endInterface.id
        ]
      })
    },
    formatRequestParams () {
      return {
        name: this.cableTemplateInfo.name,
        signalType: this.cableTemplateInfo.signalType,
        shieldType: this.cableTemplateInfo.shieldType,
        note: this.cableTemplateInfo.note,
        isCustom: this.cableTemplateInfo.isCustom,
        parameterList: this.cableTemplateInfo.isCustom ? this.cableTemplateInfo.parameterList : '',
        startInterfaceId: this.cableTemplateInfo.startParent[2],
        endInterfaceId: this.cableTemplateInfo.endParent[2]
      }
    }
  }
}
</script>

<style lang="scss">
.el-radio {
  margin-bottom: 0;
}
</style>
