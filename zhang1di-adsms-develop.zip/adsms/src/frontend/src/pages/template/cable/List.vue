<template>
    <div class="appliance-cable">
      <div class="row">
        <div class="col-sm-8 m-b-xs">
          <el-button type="primary" icon="el-icon-check" @click.native="handleVerify">审核通过</el-button>
          <el-button type="danger" icon="el-icon-delete" @click.native="handleDelete">删除</el-button>
        </div>
      </div>
      <div class="table-responsive">
        <el-table ref="multipleTable" :data="tableList" @selection-change="handleSelectionChange" height="400" border tooltip-effect="dark" style="width: 100%"  >
          <el-table-column type="selection" width="55"></el-table-column>
          <el-table-column prop="verified" type="text" label="审核状态" width="auto" sortable show-overflow-tooltip></el-table-column>
          <el-table-column prop="name" sortable label="线缆名称" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="signalType" label="信号类型" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="shieldType" label="屏蔽类型" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="note" label="备注" width="auto" show-overflow-tooltip> </el-table-column>
          <el-table-column prop="custom" label="是否定制" width="auto" sortable show-overflow-tooltip> </el-table-column>
          <el-table-column prop="parameterList" label="定制信息" width="auto" show-overflow-tooltip> </el-table-column>
          <el-table-column prop="startInterfaceName" label="起始接口" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="endInterfaceName" label="终止接口" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="createUserName" label="创建者" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column  prop="createdAt" sortable label="创建时间" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="updatedAt" sortable label="更新时间" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column label="操作" width="80">
            <template slot-scope="scope">
              <el-link @click="$router.push({ name: 'template-cable-create-or-update', query: { id: scope.row.id }})"
                icon="el-icon-edit" type="primary" class="m-r-sm">编辑
              </el-link>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="row table-pagination m-t-xs m-r-xs">
        <el-pagination
          @size-change="fetchTableList(1)"
          @current-change="fetchTableList"
          @prev-click="fetchTableList(cableTemplatesPagination.page - 1)"
          @next-click="fetchTableList(cableTemplatesPagination.page + 1)"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="cableTemplatesPagination.totalCount"
          :page-size.sync="pageSize"
          :current-page="cableTemplatesPagination.page">
        ></el-pagination>
      </div>
    </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import { formatTime } from '@/utils/tools'

export default {
  name: 'appliance-cableTemplates',
  data: () => ({
    tableList: [],
    multipleSelection: [],
    condition: {}
  }),
  computed: {
    ...mapGetters([ 'cableTemplatesPagination' ]),
    pageSize: {
      get () {
        return this.cableTemplatesPagination.pageSize
      },
      set (pageSize) {
        this.updateCableTemplatePagination({ ...this.cableTemplatesPagination, pageSize })
      }
    }
  },
  mounted () {
    this.fetchTableList()
    this.eventHub.$on('appliance-search', ({ name, condition }) => {
      if (name === 'cableTemplate') {
        this.condition = { ...condition }
        this.fetchTableList(1)
      }
    })
  },
  methods: {
    ...mapMutations([ 'updateCableTemplatePagination' ]),
    handleDelete () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要删除的线缆模板！')
      } else {
        this.$confirm('此操作将永远删除该线缆模板, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var cablesId = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.deleteCable(cablesId)
        }).catch()
      }
    },
    handleVerify () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要审核的模板线缆！')
      } else {
        this.$confirm('您将审核通过该线缆模板, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var CableTemplatesSelections = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.verifyCableTemplates(CableTemplatesSelections)
        }).catch()
      }
    },
    async deleteCable () {
      try {
        var templatesSelection = this.multipleSelection.map(function (item) {
          return item['id']
        })
        await this.$axios.delete(`/appliance/cable/templates`, {
          params: {
            ids: templatesSelection
          }
        })
        this.$message.success('删除模板成功！')
        this.fetchTableList()
      } catch (error) {
        this.$message.warn('该模板不存在！')
      }
    },
    async verifyCableTemplates () {
      try {
        var cableTemplatesSelections = this.multipleSelection.map(function (item) {
          return item['id']
        })
        await this.$axios.put(`appliance/cable/templates`, {
          ids: cableTemplatesSelections
        })
        this.$message.success('审核成功！')
        this.fetchTableList()
      } catch (error) {
        this.$message.warn('器材不存在或删除失败!')
      }
    },
    async fetchTableList (page = 1, condition = this.condition) {
      let result = await this.$axios.get('/appliance/cable/templates', {
        params: {
          ...condition,
          page: page,
          pageSize: this.cableTemplatesPagination.pageSize
        }
      })
      this.tableList = result.items.map(item => ({
        ...item,
        custom: item.isCustom ? '是' : '否',
        parameterList: item.isCustom ? item.parameterList : '无',
        verified: item.verifyUserName ? '已审核' : '未审核',
        createdAt: formatTime(item.createdAt),
        updatedAt: formatTime(item.updatedAt)
      }))
      this.updateCableTemplatePagination(result.meta)
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    }
  }
}
</script>

<style>
.el-tooltip__popper {
  max-width: 500px
}
</style>
