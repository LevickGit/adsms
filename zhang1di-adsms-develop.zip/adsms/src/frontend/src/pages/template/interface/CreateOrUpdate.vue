<template>
  <main-layout :crumbs="[{
    title: '模板管理',
    path: '/template/?tab=interface'
  }, {
    title: $route.query.id ? '更新接口模板' : '新增接口模板'
  }]">
    <div class="container-fluid">
      <div class="row">
        <div class="el-col-10 el-col-offset-7 text-center">
          <h2 class="text-center">接口模板信息录入</h2>
          <el-form ref="form" :model="interfaceTemplateInfo" status-icon label-width="100px" size="medium">
            <el-form-item label="接口名称：" focus prop="name">
              <el-input name="name" v-model.trim="interfaceTemplateInfo.name" type="text" autocomplete="on" />
            </el-form-item>
            <el-form-item label="接口类型：" prop="type">
              <el-input name="type" v-model.trim="interfaceTemplateInfo.type" type="text" autocomplete="off" />
            </el-form-item>
            <el-form-item label="接口协议：" prop="protocol">
              <el-input name="protocol" v-model.trim="interfaceTemplateInfo.protocol" type="text" aria-autocomplete="true" />
            </el-form-item>
            <el-form-item label="接口位置：" prop="location">
              <el-input name="location" v-model.trim="interfaceTemplateInfo.location" autocomplete="off"/>
            </el-form-item>
            <el-form-item label="PCL：" prop="pcl">
              <el-input name="pcl" v-model.trim="interfaceTemplateInfo.pcl" type="text" autocomplete="off"/>
            </el-form-item>
            <el-form-item label="父级设备：" prop="note">
              <el-cascader
                class="full-width"
                v-model="interfaceTemplateInfo.parent"
                placeholder="装置名/设备名"
                :options="deviceMeta"
                filterable>
              </el-cascader>
            </el-form-item>
            <el-form-item label="备注：" prop="note">
              <el-input name="note" v-model.trim="interfaceTemplateInfo.note" :show-word-limit="true" :maxlength="125" type="textarea" :autosize="{ minRows: 2, maxRows: 4}"/>
            </el-form-item>
            <el-form-item>
              <el-button size="large" type="primary" @click="submit">提交</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="row m-t-md">
        <keep-alive>
          <router-view @next-step="next" @last-step="last"/>
        </keep-alive>
      </div>
    </div>
  </main-layout>
</template>
<script>
import { mapGetters } from 'vuex'

export default {
  name: 'interfaceTemplatesManagement',
  data: () => ({
    keyword: '',
    interfaceTemplateInfo: {
      name: '',
      type: '',
      protocol: '',
      location: '',
      pcl: '',
      note: '',
      parent: ''
    },
    templateInfo: []
  }),
  computed: {
    ...mapGetters(['deviceMeta'])
  },
  created () {
    if (this.$route.query.id) {
      this.fetchInterface(this.$route.query.id)
    }
  },
  methods: {
    submit () {
      this.$refs.form.validate().then(() => {
        let id = this.$route.query.id
        let params = this.formatRequestParams()
        id ? this.$axios.put(`appliance/interface/template/${id}`, params).then(response => {
          if (response.ok) {
            this.$message.success('更新接口模板成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'interface' }
            })
          } else {
            this.$message.error(response.msg)
          }
        }) : this.$axios.post('appliance/interface/template', params).then(response => {
          if (response.ok) {
            this.$message.success('创建接口模板成功')
            this.$router.push({
              name: 'appliance',
              query: { tab: 'interface' }
            })
          } else {
            this.$message.error(response.msg)
          }
        })
      })
    },
    fetchInterface (id) {
      this.$axios.get(`appliance/interface/${id}`).then(_interface => {
        this.interfaceTemplateInfo.name = _interface.name
        this.interfaceTemplateInfo.type = _interface.type
        this.interfaceTemplateInfo.location = _interface.location
        this.interfaceTemplateInfo.protocol = _interface.protocol
        this.interfaceTemplateInfo.pcl = _interface.pcl
        this.interfaceTemplateInfo.note = _interface.note
        this.interfaceTemplateInfo.parent = [_interface.parentEquipment.id, _interface.parentDevice.id]
      })
    },
    formatRequestParams () {
      return {
        name: this.interfaceTemplateInfo.name,
        type: this.interfaceTemplateInfo.type,
        location: this.interfaceTemplateInfo.location,
        protocol: this.interfaceTemplateInfo.protocol,
        pcl: this.interfaceTemplateInfo.pcl,
        note: this.interfaceTemplateInfo.note,
        parentDeviceId: this.interfaceTemplateInfo.parent[1]
      }
    }
  }
}
</script>
