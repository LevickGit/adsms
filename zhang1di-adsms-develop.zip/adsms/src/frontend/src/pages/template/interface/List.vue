<template>
    <div class="appliance-connector">
      <div class="row">
        <div class="col-sm-8 m-b-xs">
          <el-button type="primary" icon="el-icon-check" @click.native="handleVerify">审核通过</el-button>
          <el-button type="danger" icon="el-icon-delete" @click.native="handleDelete">删除</el-button>
        </div>
      </div>
      <div class="table-responsive">
        <el-table fit ref="multipleTable" :data="templateList" @selection-change="handleSelectionChange" height="400" border tooltip-effect="dark">
          <el-table-column type="selection" width="55" align="center"></el-table-column>
          <el-table-column prop="verified" label="审核状态" width="auto" sortable show-overflow-tooltip></el-table-column>
          <el-table-column prop="name" sortable label="接口名称" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="type" label="接口类型" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="protocol" label="接口协议类型" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="location" sortable label="接口位置" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="note" sortable label="备注" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="createUserName" sortable label="创建者" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="createdAt" sortable label="创建时间" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column prop="updatedAt" sortable label="更新时间" width="auto" show-overflow-tooltip></el-table-column>
          <el-table-column label="操作" width="80">
            <template slot-scope="scope">
              <el-link @click="$router.push({ name: 'template-interface-create-or-update', query: { id: scope.row.id }})"
                icon="el-icon-edit" type="primary" class="m-r-sm">编辑
              </el-link>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="row table-pagination m-t-xs m-r-xs">
        <el-pagination
          @size-change="fetchtemplateList(1)"
          @current-change="fetchtemplateList"
          @prev-click="fetchtemplateList(interfaceTemplatesPagination.page - 1)"
          @next-click="fetchtemplateList(interfaceTemplatesPagination.page + 1)"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="interfaceTemplatesPagination.totalCount"
          :page-size.sync="pageSize"
          :current-page="interfaceTemplatesPagination.page">
        ></el-pagination>
      </div>
    </div>
</template>

<script>
import { mapGetters, mapMutations } from 'vuex'
import { formatTime } from '@/utils/tools'
export default {
  name: 'appliance-interfaceTemplates',
  data: () => ({
    templateList: [],
    multipleSelection: [],
    condition: {}
  }),
  computed: {
    ...mapGetters([ 'interfaceTemplatesPagination' ]),
    pageSize: {
      get () {
        return this.interfaceTemplatesPagination.pageSize
      },
      set (pageSize) {
        this.updateInterfaceTemplatePagination({ ...this.interfaceTemplatesPagination, pageSize })
      }
    }
  },
  mounted () {
    this.fetchtemplateList()
    this.eventHub.$on('appliance-search', condition => {
      this.fetchtemplateList(1, condition)
    })
    this.eventHub.$on('appliance-search', ({ name, condition }) => {
      if (name === 'interfaceTemplate') {
        this.condition = { ...condition }
        this.fetchTableList(1)
      }
    })
  },
  methods: {
    ...mapMutations(['updateInterfaceTemplatePagination']),
    handleDelete () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要删除的接口模板！')
      } else {
        this.$confirm('此操作将永远删除该接口模板, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var interfaceId = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.deleteInterface(interfaceId)
        }).catch()
      }
    },
    handleVerify () {
      if (this.multipleSelection.length === 0) {
        this.$message.warning('您未选择想要审核的接口模板！')
      } else {
        this.$confirm('您将审核通过该接口模板, 是否继续?', '提示', {
          duration: 600,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          var InterfaceTemplatesSelections = this.multipleSelection.map(function (item) {
            return item['id']
          })
          this.verifyInterfaceTemplates(InterfaceTemplatesSelections)
        }).catch()
      }
    },
    async deleteInterface () {
      try {
        var templatesSelection = this.multipleSelection.map(function (item) {
          return item['id']
        })
        await this.$axios.delete(`appliance/interface/templates`, {
          params: {
            ids: templatesSelection
          }
        })
        this.$message.success('删除成功!')
        this.fetchtemplateList()
      } catch (error) {
        this.$message.warning('接口不存在!')
      }
    },
    async verifyInterfaceTemplates () {
      try {
        var InterfaceTemplatesSelections = this.multipleSelection.map(function (item) {
          return item['id']
        })
        await this.$axios.put(`appliance/interface/templates`, {
          ids: InterfaceTemplatesSelections
        })
        this.$message.success('审核成功!')
        this.fetchtemplateList()
      } catch (error) {
        this.$message.warn('器材不存在!')
      }
    },
    async fetchtemplateList (page = 1, condition = this.condition) {
      let result = await this.$axios.get('appliance/interface/templates', {
        params: {
          ...condition,
          pageSize: this.interfaceTemplatesPagination.pageSize
        }
      })
      this.templateList = result.items.map(item => ({
        ...item,
        verified: item.verifyUserName ? '已审核' : '未审核',
        createdAt: formatTime(item.createdAt),
        updatedAt: formatTime(item.updatedAt)
      }))
      this.updateInterfaceTemplatePagination(result.meta)
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
    }
  }
}
</script>
