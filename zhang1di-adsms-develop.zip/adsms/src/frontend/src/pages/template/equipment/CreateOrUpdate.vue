<template>
  <main-layout :crumbs="[{
    title: '模板管理',
    path: '/template/?tab=equipmentTemplate'
  }, {
    title: $route.query.id ? '更新装置模板' : '新增装置模板'
  }]">
    <div class="container-fluid">
      <div class="row">
        <div class=" el-col-10 el-col-offset-7 text-center center">
          <h2 class="text-center">装置模板信息录入</h2>
          <el-form :model="equipmentTemplateInfo" status-icon ref="form" label-width="100px" size="medium">
            <el-form-item label="装置名称：" focus prop="name">
              <el-input name="name" type="text" v-model.trim="equipmentTemplateInfo.name" autocomplete="on"></el-input>
            </el-form-item>
            <el-form-item label="装置类型：" prop="type">
              <el-input name="type" type="text" v-model.trim="equipmentTemplateInfo.type" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="装置位置：" prop="location">
              <el-input name="location" type="text" v-model.trim="equipmentTemplateInfo.location"></el-input>
            </el-form-item>
            <el-form-item label="序列号：" prop="sn">
              <el-input name="sn" type="text" v-model.trim="equipmentTemplateInfo.sn" autocomplete="off"></el-input>
            </el-form-item>
            <el-form-item label="生产厂商：" prop="manufacturer">
              <el-input name="manufacturer" v-model.trim="equipmentTemplateInfo.manufacturer"></el-input>
            </el-form-item>
            <el-form-item label="备注：" prop="note">
              <el-input name="note" :show-word-limit="true" :maxlength="100" type="textarea" :autosize="{ minRows: 2, maxRows: 4}" v-model.trim="equipmentTemplateInfo.note"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button size="large" type="primary" @click="submit">提交</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
    </div>
  </main-layout>
</template>

<script>
export default {
  name: 'equipmentTemplatesManagement',
  data: () => ({
    keyword: '',
    equipmentTemplateInfo: {
      name: '',
      type: '',
      location: '',
      sn: '',
      manufacturer: '',
      note: ''
    },
    templateInfo: []
  }),
  created () {
    if (this.$route.query.id) {
      this.fetchEquipment(this.$route.query.id)
    }
  },
  methods: {
    submit () {
      this.$refs.form.validate().then(() => {
        let id = this.$route.query.id
        id ? this.$axios.put(`appliance/equipment/template/${id}`, this.equipmentTemplateInfo).then(response => {
          if (response.ok) {
            this.$message.success('更新装置模板成功')
            this.$router.push({
              name: 'template',
              query: { tab: 'equipmentTemplate' }
            })
          } else {
            this.$message.error(response.msg)
          }
        }) : this.$axios.post('appliance/equipment/template', this.equipmentTemplateInfo).then(response => {
          if (response.ok) {
            this.$message.success('创建装置模板成功')
            this.$router.push({
              name: 'template',
              query: { tab: 'equipmentTemplate' }
            })
          } else {
            this.$message.error(response.msg)
          }
        })
      })
    },
    fetchEquipment (id) {
      this.$axios.get(`appliance/equipment/${id}`).then(equipment => {
        this.equipmentTemplateInfo.name = equipment.name
        this.equipmentTemplateInfo.type = equipment.type
        this.equipmentTemplateInfo.location = equipment.location
        this.equipmentTemplateInfo.sn = equipment.sn
        this.equipmentTemplateInfo.manufacturer = equipment.manufacturer
        this.equipmentTemplateInfo.note = equipment.note
      })
    }
  }
}
</script>
