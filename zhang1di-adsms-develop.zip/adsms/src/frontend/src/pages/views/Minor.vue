<template>
  <main-layout>
    <div class="wrapper wrapper-content animated fadeInRight">
      <div class="row">
        <div class="col-lg-12">
          <div class="text-center m-t-lg">
            <h1>Sample example of second view</h1>
            <small>Written in Minor.js component</small>
          </div>
        </div>
      </div>
    </div>
  </main-layout>
</template>
