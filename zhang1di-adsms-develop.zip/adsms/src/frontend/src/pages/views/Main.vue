<template>
  <main-layout>
    <div class="row">
      <div class="col-lg-12">
        <el-form status-icon label-width="100px">
          <el-form-item label="头像" prop="avatar">
            <el-upload
              multiple
              action="/api/resource/image"
              :headers="headers"
              :show-file-list="true"
              :on-success="uploadSuccess"
              :on-remove="imageRemove"
              list-type="picture">
              <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </main-layout>
</template>

<script>
import { mapGetters } from 'vuex'
export default {
  name: 'main-page',
  data: () => ({
    fileList: []
  }),
  computed: {
    ...mapGetters(['headers'])
  },
  methods: {
    uploadSuccess (response) {
      console.log(response)
    },
    imageRemove (params) {
      console.log(params)
    }
  }
}
</script>
