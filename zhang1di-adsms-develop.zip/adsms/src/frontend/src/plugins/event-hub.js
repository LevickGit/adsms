import Vue from 'vue'

Vue.prototype.eventHub = new Vue()
