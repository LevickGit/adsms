import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

export default new VueRouter({
  mode: 'hash',
  routes: [{
    path: '/',
    redirect: '/appliance'
  },
  {
    path: '/login',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '../pages/Login.vue')
  }, {
    path: '/system/setup',
    name: 'system-setup',
    meta: {
      title: '系统设置'
    },
    component: () => import(/* webpackChunkName: "system-setup" */ '../pages/system/Setup.vue')
  }, {
    path: '/account/list',
    name: 'account-list',
    meta: {
      title: '用户管理'
    },
    component: () => import(/* webpackChunkName: "account-list" */ '../pages/account/List.vue')
  }, {
    path: '/account/create',
    name: 'account-create',
    meta: {
      title: '新增用户'
    },
    component: () => import(/* webpackChunkName: "account-create" */ '../pages/account/Create.vue')
  }, {
    path: '/account/failed-detail/:id',
    name: 'account-failed-detail',
    meta: {
      title: '用户导入结果'
    },
    component: () => import(/* webpackChunkName: "account-create" */ '../pages/account/FailedDetail.vue')
  }, {
    path: '/account/profile',
    name: 'account-profile',
    meta: {
      title: '个人中心'
    },
    component: () => import(/* webpackChunkName: "account-profile" */ '../pages/account/Profile.vue')
  }, {
    path: '/appliance',
    name: 'appliance',
    meta: {
      title: '器材管理'
    },
    component: () => import(/* webpackChunkName: "appliance" */ '../pages/appliance/Appliance.vue')
  }, {
    path: '/template',
    name: 'template',
    meta: {
      title: '模板管理'
    },
    component: () => import(/* webpackChunkName: "template" */ '../pages/template/Template.vue')
  }, {
    path: '/recycles',
    name: 'recycles',
    meta: {
      title: '回收站'
    },
    component: () => import(/* webpackChunkName: "recycles" */ '../pages/recycle/Recycles.vue')
  }, {
    path: '/appliance/device/create-or-update',
    name: 'appliance-device-create-or-update',
    component: () => import(/* webpackChunkName: "appliance-device-create" */ '../pages/appliance/device/CreateOrUpdate.vue')
  }, {
    path: '/appliance/interface/create-or-update',
    name: 'appliance-interface-create-or-update',
    component: () => import(/* webpackChunkName: "appliance-interface-create" */ '../pages/appliance/interface/CreateOrUpdate.vue')
  }, {
    path: '/appliance/equipment/create-or-update',
    name: 'appliance-equipment-create-or-update',
    component: () => import(/* webpackChunkName: "appliance-device-create" */ '../pages/appliance/equipment/CreateOrUpdate.vue')
  }, {
    path: '/appliance/cable/create-or-update',
    name: 'appliance-cable-create-or-update',
    component: () => import(/* webpackChunkName: "appliance-cable-create" */ '../pages/appliance/cable/CreateOrUpdate.vue')
  }, {
    path: '/template/device/create-or-update',
    name: 'template-device-create-or-update',
    component: () => import(/* webpackChunkName: "template-device-create" */ '../pages/template/device/CreateOrUpdate.vue')
  }, {
    path: '/template/interface/create-or-update',
    name: 'template-interface-create-or-update',
    component: () => import(/* webpackChunkName: "template-interface-create" */ '../pages/template/interface/CreateOrUpdate.vue')
  }, {
    path: '/template/equipment/create-or-update',
    name: 'template-equipment-create-or-update',
    component: () => import(/* webpackChunkName: "template-device-create" */ '../pages/template/equipment/CreateOrUpdate.vue')
  }, {
    path: '/template/cable/create-or-update',
    name: 'template-cable-create-or-update',
    component: () => import(/* webpackChunkName: "template-cable-create" */ '../pages/template/cable/CreateOrUpdate.vue')
  }
  ]
})
