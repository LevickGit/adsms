> 接口设计

备注：

1. 对于响应内容，如无特殊说明，则：  

- 成功：状态码为200，内容为 "success"
- 失败：状态码为400，内容为 "failure"

2. 请求头说明  

所有接口授权都基于 `Authorization` 头部，`token` 需要加上 `Bearer` 前缀，例如:  

```js
Authorization: Bearer hasudhaishdoiahsdi***
```

# 访问控制接口

## 用户登陆

地址: /account/login  
类型: POST  
权限: 普通用户  
请求参数:  

名称|类型|必填|备注|样例
---|---|---|---|---
username|String|是|用户名|local@qq.com
password|String|是|密码  |Abac123__

请求响应:  

- 状态码 200  

```js
{
    "token": fields.String,
    "expired_at": fields.Integer
}
```

- 状态码 400  

```json
{
    "msg": "login failed"
}
```

## 用户注销

地址: /account/logout  
类型: POST  
权限: 普通用户  
请求参数: 无  
请求响应:  

- 状态码 200

```json
{
    "msg": "success"
}
```

## 获取登陆用户信息

地址: /account/current  
类型: GET  
权限: 普通用户  
请求参数: 无  
请求响应:  

- 状态码 200

```js
{
    "id": fields.String,
    "username": fields.String,
    "email": fields.String,
    "position": fields.String,
    "department": fields.String,
    "phone": fields.String,
    "admin": fields.Boolean,
    "superuser": fields.Boolean
}
```

# 系统设置接口

## 获取所有设置信息  

地址: /system/settings  
类型: GET  
权限: 普通用户  
请求参数: 无  
请求响应:  

- 状态码 200  

```js
{
    "departments": fields.List,
    "positions": fields.List,
    "shieldTypes": fields.List,
    "spliceTypes": fields.List,
    "interfaceProtocols": fields.List
}
```

## 添加

地址: /system/settings  
类型: PUT  
权限: 管理员  
请求参数:  

名称|类型|必填|备注|样例
---|---|---|---|---
name|String|是|类别|departments
value|String|是|所有职位|先进核能材料研究室

请求响应:  

- 状态码 200

```js
{
    "departments": fields.List,
    "positions": fields.List,
    "shieldTypes": fields.List,
    "spliceTypes": fields.List,
    "interfaceProtocols": fields.List
}
```

- 状态码 400

```json
{
    "msg": "params invalid"
}
```

## 删除

地址: /system/settings  
类型: DELETE  
权限: 管理员  
请求参数:  

| 名称  | 类型   | 必填 | 备注 | 样例      |
| ----- | ------ | ---- | ---- | --------- |
| name  | String | 是   | 类别 | positions |
| value | String | 是   | 值   | 组长      |

请求响应:  

- 状态码 200

```js
{
    "departments": fields.List,
    "positions": fields.List,
    "shieldTypes": fields.List,
    "spliceTypes": fields.List,
    "interfaceProtocols": fields.List
}
```

- 状态码 400

```json
{
    "msg": "params invalid"
}
```

------------

# 用户管理接口

## 获取所有用户

地址: /account/users  
类型: GET  
权限: 管理员  
请求参数:  

名称|类型|必填|备注|样例
---|---|---|---|---
page |Integer|否|页数，默认值1|
pageSize|Integer|否|每页数量，默认10|
orderBy|Object|否|排序，desc为降序，asc为升序|{ username: "desc" }
searchKey|String|否|搜索关键字，可以搜索姓名、邮箱、手机号|
department|String|否|过滤部门|
position|String|否|过滤职位|

请求响应:  

- 状态码 200

```js
{
    "items": [
        user_fields,
        user_fields,
        ...
    ],
    "meta": {
        "page": fields.Integer,
        "pageSize": fields.Integer,
        "pageCount": fields.Integer,
        "totalCount": fields.Integer
    }
user_fields = {
        "id": fields.String,
        "username": fields.String,
        "email": fields.String,
        "avatar": fields.String,
        "position": fields.String,
        "department": fields.String,
        "phone": fields.String,
        "searchNum": fields.Integer,
        "loginNum": fields.Integer,
        "authorType": fields.Integer,
    }
}
```

## 根据id获取用户信息

地址: /account/user/{id}  
类型: GET  
权限: 管理员  
请求参数: 无  
请求响应:    

- 状态码 200

```js
{
    	"id": fields.String,
        "username": fields.String,
        "email": fields.String,
        "avatar": fields.String,
        "position": fields.String,
        "department": fields.String,
        "phone": fields.String,
        "searchNum": fields.Integer,
        "loginNum": fields.Integer,
        "authorType": fields.Integer,
}
```

- 状态码 404  

```js
{
    "msg": "not found"
}
```

## 更新用户信息

地址: /account/user/{id}  
类型: PUT  
权限: 管理员  
请求参数:  

名称|类型|必填|备注|样例
---|---|---|---|---
phone |String|是|电话号码|
username|String|是|用户名|
position|String|是|职位|
department|String|是|部门|
avatar|String|是|头像|

请求响应:  

- 状态码 200

```js
{
    "ok"="True", 
    "msg"='success'
}
```

- 状态码 400

```js
{
    "msg": "params invalid"
}
```

- 状态码 404

```js
{
    "msg": "not found"
}
```

## 创建用户信息

地址: /account/user  
类型: POST  
权限: 管理员  
请求参数:  

名称|类型|必填|备注|样例
---|---|---|---|---
phone |String|是|电话号码|
email |String|是|电子邮箱|
username|String|是|用户名|
position|String|是|职位|
department|String|是|部门|
avatar|String|是|头像|

请求响应:  

- 状态码 200

```js
{
    "ok"="True", 
    "msg"='success'
}
```

- 状态码 400

```js
{
    "msg": "params invalid" // or "email already exists"
}
```

- 状态码 404

```js
{
    "msg": "not found"
}
```

## 删除用户信息

地址: /account/user/{id}  
类型: DELETE  
权限: 管理员  
请求参数:  
名称|类型|必填|备注|样例
---|---|---|---|---
name|String|是|设备名称|设备1
请求响应:  

- 状态码 200

```js
{
    "ok"="True", 
    "msg"='success'
}
```

- 状态码 404

```js
{
    "msg": "not found"
}
```

## 批量删除用户

地址：/account/users  
类型：DELETE  
权限：管理员
请求参数：  

>| 名称    | 类型         | 必填 | 备注 | 样例 |
>| ------- | ------------ | ---- | ---- | ---- |
>| userIds | ObjectIdList | 否   |      |      |

请求响应：  
-状态码：200

```js
{
    "ok"="True", 
    "msg"='success'
}
```

## 用户密码修改

地址: /account/password  
类型: PUT  
权限: 管理员  
请求参数:  

名称|类型|必填|备注
---|---|---|---
newPassword|String|是|用户新密码

请求响应:  

- 状态码 200

```js
{
    "ok"="True", 
    "msg"='success'
}
```

- 状态码：400

```js
{
    "msg" : "'new password is invalid'"
}
```

- 状态码：404

```js
{
    "msg" : "not found"
}
```

## 批量重置密码

地址: /account/users/passwords  
类型: PUT  
权限: 管理员  
请求参数:  

| 名称 | 类型         | 必填 | 备注 |
| ---- | ------------ | ---- | ---- |
| ids  | ObjectIdList | 是   |      |

请求响应:  

- 状态码 200

```js
{
    "ok"="True", 
    "msg"='success'
}
```

## 批量提权  

地址: /account/users/permission  
类型: PUT  
权限: 管理员  
请求参数:  

| 名称 | 类型         | 必填 | 备注 |
| ---- | ------------ | ---- | ---- |
| ids  | ObjectIdList | 是   |      |

请求响应:  

- 状态码 200

```js
{
    "ok"="True", 
    "msg"='success'
}
```

## 批量降权  

地址: /account/users/permission   

类型: DELETE

权限: 管理员   

请求参数:  

| 名称 | 类型         | 必填 | 备注 |
| ---- | ------------ | ---- | ---- |
| ids  | ObjectIdList | 是   |      |

请求响应:  

- 状态码 200  

```js
{
    "ok"="True", 
    "msg"='success'
}
```

## 获取已删除用户  

地址：account/users/recycles  

类型：GET  

权限：管理员  

请求参数：  
| 名称      | 类型   | 必填 | 备注                                       | 样例 |
| --------- | ------ | ---- | ------------------------------------------ | ---- |
| searchKey | String | 否   | 返回name或email包含searchKey。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        user_field,
        user_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```

## 撤销删除

地址：account/users/recycles  

类型：PUT  

权限：管理员  

请求参数：

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  
```js
{
    "ok"="True", 
    "msg"='success'
}
```

## 彻底删除

地址：account/users/recycles  

类型：DELETE  

权限：管理员  

请求参数：

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  
```js
{
    "ok"="True", 
    "msg"='success'
}
```

------------

# 装置(equipment)管理接口(by:yz)  

## 添加一个装置  

地址：/appliance/equipment  

类型：POST  

权限：普通用户  

请求参数：  

| 名称         | 类型   | 必填 | 备注     | 样例 |
| ------------ | ------ | ---- | -------- | ---- |
| name         | String | 是   | 装置名称 |      |
| type         | String | 是   | 类型     |      |
| location     | String | 是   | 位置     |      |
| sn           | String | 是   | 序列号   |      |
| manufacturer | String | 是   | 制造商   |      |
| note         | String | 否   | 备注     |      |

- 状态码 200  

```js
{
   "ok"："True",
   "msg"："success",
   "id":equipment.id
}
```

- 状态码 400  

```js
form.errors //表单验证失败
```

## 更新一个装置  

地址：/appliance/equipment/{id}  

类型：PUT  

权限：管理员或拥有者   

请求参数：  

| 名称         | 类型   | 必填 | 备注     | 样例 |
| ------------ | ------ | ---- | -------- | ---- |
| name         | String | 是   | 装置名称 |      |
| type         | String | 是   | 类型     |      |
| location     | String | 是   | 位置     |      |
| sn           | String | 是   | 序列号   |      |
| manufacturer | String | 是   | 制造商   |      |
| note         | String | 否   | 备注     |      |

- 状态码 200  

```js
{
   "ok"："True",
   "msg"："success"
}
```

- 状态码 400  

```js
{
	"msg" : form.errors
}
```

- 状态码 403  

```js
{
    "ok":"False",
	"msg" : "no  updatable" 
} 
```

- 状态码 404  

```js
{
    "ok":"Flase",
	"msg" : "not found"
}
```

## 通过id获取一个装置  

地址：appliance/equipment/{id}  

类型：GET  

权限：普通用户  

请求参数：无  

- 状态码 200  

```js
{
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'sn': fields.String,
    'manufacturer': fields.String,
    'note': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUserName':fields.String,
    'updateUserName': fields.String,
    'updateNum': fields.Integer
}
```

- 状态码 404  

```js
{
    "ok": "False",
	"msg" : "not found"
}
```

## 获取所有装置  

地址：appliance/equipments  

类型：GET  

权限：普通用户  

请求参数：无  

-  状态码 200  

```js
{
    "items": [
        equipment_field,
        equipment_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}

equipment_fields = {
     'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'sn': fields.String,
    'manufacturer': fields.String,
    'note': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUserName':fields.String,
    'updateUserName': fields.String,
    'updateNum': fields.Integer
}

```

## 查询装置  

地址：appliance/equipments  

类型：GET  

权限：普通用户  

请求参数：  

| 名称           | 类型     | 必填 | 备注                                    | 样例 |
| -------------- | -------- | ---- | --------------------------------------- | ---- |
| searchKey      | String   | 否   | 返回name,note中包含searchKey的documents |      |
| name           | String   | 否   |                                         |      |
| location       | String   | 否   |                                         |      |
| type           | String   | 否   |                                         |      |
| sn             | String   | 否   |                                         |      |
| manufacturer   | String   | 否   |                                         |      |
| createUserName     | String   | 否   | 创建者的名字                            |      |
| createdAtStart | DateTime | 否   | 创建时间 起始值                         |      |
| createdAtEnd   | DateTime | 否   | 创建时间 终止值                         |      |
| orderBy        | Json     | 否   | 由key和sort组成                         |      |
- 状态码 200  

```js
{
    "items": [
        equipment_field,
        equipment_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}

equipment_fields = {
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'sn': fields.String(),
    'manufacturer': fields.String,
    'note': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUserName': fields.String,
    'updateUserName': fields.String,
    'updateNum': fields.Integer
}
```

## 删除一个装置  

地址：appliance/equipment/{id}  

类型：DELETE  

权限：管理员或拥有者  

请求参数：无  

- 状态码 200  

```js
{
    "ok":"True",
    "msg" : "success"
}
或
{
    "ok":"True"
    "msg" : "not found"
}
```

## 查询子器材  

地址：appliance/equipment/child/{id}  

类型：GET

权限：普通用户  

请求参数：无  

- 状态码 200  

```js
{
    "ok":"True",
    "msg" : {
            'device': child_device,   //child_device是个整数
            'interface': child_interface,
            'cable': child_cable
    }
}
```

- 状态码 404  

```js
{
    "ok":"False",
    "msg" : "not found"
}
```

## 批量删除  

地址：appliance/equipments  

类型：DELETE  

权限：管理员

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok":"True",
    "msg" : "success"
}
```

## 查询多个装置的子器材  

地址：appliance/equipments/child  

类型：GET  

权限：普通用户 

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok":"True",
    "msg" : {
            'device': child_device,   //所有装置的子设备总数
            'interface': child_interface,
            'cable': child_cable
    }
}
```

- 状态码 404  

```js
{
    "ok":"False",
    "msg" : "not found"
}
```

## 复刻模板

地址：appliance/equipment/templates

类型：POST

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注         | 样例 |
| ---- | ------------ | ---- | ------------ | ---- |
| ids  | ObjectIdList | 否   | 一组装置的id |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 审核模板

地址：appliance/equipment/templates

类型：PUT

权限：管理员 

请求参数：  

| 名称 | 类型         | 必填 | 备注         | 样例 |
| ---- | ------------ | ---- | ------------ | ---- |
| ids  | ObjectIdList | 否   | 一组装置的id |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 获取模板

地址：appliance/equipment/templates

类型：GET 

权限：普通用户  

请求参数：  

| 名称      | 类型    | 必填 | 备注                                            | 样例 |
| --------- | ------- | ---- | ----------------------------------------------- | ---- |
| searchKey | String  | 否   | 返回name或note包含searchKey的模板。不填返回所有 |      |
| verified  | Boolean | 否   | 为true时，只返回已审核的                        |      |

- 状态码 200  

```
{    
	{
    "items": [
        equipment_template_field,
        equipment_template_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}

equipment_template_fields = {
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'sn': fields.String(),
    'manufacturer': fields.String,
    'note': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUserName': fields.String,
    'updateUserName': fields.String,
    'updateNum': fields.Integer,
	'verifyUserName': fields.String
}
```

## 移除模板

地址：appliance/equipment/templates

类型：DELETE

权限：管理员  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 更新模板信息  

地址：/appliance/equipment/template/{id}  

类型：PUT  

权限：管理员或拥有者   

请求参数：  

| 名称         | 类型   | 必填 | 备注     | 样例 |
| ------------ | ------ | ---- | -------- | ---- |
| name         | String | 否   | 装置名称 |      |
| type         | String | 否   | 类型     |      |
| location     | String | 否   | 位置     |      |
| sn           | String | 否   | 序列号   |      |
| manufacturer | String | 否   | 制造商   |      |
| note         | String | 否   | 备注     |      |

- 状态码 200  

```js
{
   "ok"："True",
   "msg"："success"
}
```

- 状态码 403  

```js
{
    "ok":"False",
	"msg" : "no  updatable" 
} 
```

- 状态码 404  

```js
{
    "ok":"Flase",
	"msg" : "not found"
}
```

## 获取已删除装置  

地址：appliance/equipments/recycles  

类型：GET  

权限：普通用户  

请求参数：  

| 名称      | 类型   | 必填 | 备注                                      | 样例 |
| --------- | ------ | ---- | ----------------------------------------- | ---- |
| searchKey | String | 否   | 返回name或note包含searchKey。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        equipment_field,
        equipment_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```
## 获取已删除装置模板

地址：appliance/equipments/templates/recycles

类型：GET

权限：普通用户  

请求参数：  

| 名称      | 类型   | 必填 | 备注                                        | 样例 |
| --------- | ------ | ---- | ------------------------------------------- | ---- |
| searchKey | String | 否   | 返回name或note包含searchKey的。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        equipment_template_field,
        equipment_template_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```

## 撤销删除装置或装置模板

地址：appliance/equipments/recycles  

类型：PUT  

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

## 彻底删除装置或装置模板

地址：appliance/equipments/recycles  

类型：DELETE  

权限：普通用户  

请求参数：  

| 名称  | 类型          | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

------------

# 设备（device）管理接口(by:lcs)

## 获取所有设备

地址： /appliance/devices  
类型：GET  
权限：普通用户  
请求参数：无  
请求响应：  

- 状态码：200

```js
{
    "items": [
        device_list_fied,
        device_list_fied,
        ...
    ],
    "meta": {
        "page": fields.Integer,
        "pageSize": fields.Integer,
        "pageCount": fields.Integer,
        "totalCount": fields.Integer
    }
}

device_list_fied = {
        'id': fields.String,
        'name': fields.String,
        'type': fields.String,
        'location': fields.String,
        'system': fields.String,
        'sn': fields.String,
        'manufacture': fields.String,
        'note': fields.String,
        'parentEquipmentName': fields.String,
        'images': fields.String,
        'createdAt': fields.DateTime,
        'updatedAt': fields.DateTime,
        'createUserName': fields.String,
        'updateUserName': fields.String,
        'updateNum': fields.Integer
}
````

## 通过id获取设备

地址：/appliance/device/{id}  
类型：GET  
权限：普通用户  
请求参数：无  
请求响应：  

- 状态码：200

```js
{
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'system': fields.String,
    'sn': fields.String,
    'manufacture': fields.String,
    'note': fields.String,
    'parentEquipmentName': fields.Nested,
    'images': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUserName': fields.String,
    'updateUserName': fields.String,
    'updateNum': fields.Integer
}
```

- 状态码：404

```js

{
    "msg" : "not found"
}
```

## 添加设备

地址：/appliance/device  
类型：POST  
权限：普通用户  
请求参数：  

名称|类型|必填|备注|样例
---|---|---|---|---
name|String|是|设备名称|设备1
type|String|是|设备类型|冷却设备
sn|String|是|设备SN|UJN526542
system|String|是|设备系统|嵌入式Linux
location|String|是|设备位置|桥架1-11
note|String|否|设备备注|设备位于XXX，系统为XXX
manufacture|String|是|设备生产厂商|四川长虹

请求响应：  

- 状态码：200

```js
{
   "ok": "True",
   "msg": "success",
   "id": equipment.id
}
```

- 状态码 400

```js
form.errors //表单验证失败
```

- 状态码 404  

> *如果父级装置没找到,则返回404*

```js
{
    "msg" : "not found"
}
```

## 删除设备

地址：/appliance/device/{id}  
类型：DELETE  
权限：管理员或拥有者  
请求参数：  无

请求响应：

- 状态码：200

```js
{
    "ok":"True",
    "msg" : "success"
}
或
{
    "ok":"True"
    "msg" : "not found"
}
```

## 查询子器材  

地址：appliance/device/child/{id}  

类型：GET  

权限：普通用户  

请求参数：无  

- 状态码 200  

```js
{
    "ok":"True",
    "msg" : {
            'interface': child_interface, //child_interface是个整数
            'cable': child_cable
    	}
}
```

- 状态码 404  

```js
{
    "ok":"False",
    "msg" : "not found"
}
```

## 批量删除设备

地址：/appliance/devices  
类型：DELETE  
权限：管理员  
请求参数：  

名称|类型|必填|备注|样例
---|---|---|---|---
ids|ObjectIdList|是|要删除的设备ID|

请求响应：  

- 状态码：200

```js
{
    "ok":"True"
    "msg":"success"
}
```

## 查询多个设备的子器材  

地址：appliance/devices/child  

类型：GET  

权限：普通用户 

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok":"True",
    "msg" : {  
            'interface': child_interface,  //所有设备的子接口总数
            'cable': child_cable
    }
}
```

- 状态码 404  

```js
{
    "ok":"False",
    "msg" : "not found"
}
```

## 修改设备信息  

地址：/appliance/device/{id}  
类型：PUT  
权限：管理员或拥有者  
请求参数：

名称|类型|必填|备注|样例
---|---|---|---|---
name|String|是|设备名称|设备1
type|String|是|设备类型|冷却设备
sn|String|是|设备SN|UJN526542
system|String|是|设备系统|嵌入式Linux
location|String|是|设备位置|桥架1-11
note|String|否|设备备注|设备位于XXX，系统为XXX
manufacture|String|是|设备生产厂商|四川长虹
parentEquipment|String|是|父级装置id|冷却装置

请求响应：

- 状态码：200

```js
{
   "ok"："True",
   "msg"："success",
   "id":equipment.id
}
```

- 状态码：400

```js
例：设备名不填写，则返回form中的错误所在
{
    "name": [
        "Field must be between 1 and 125 characters long."
    ]
}
```

- 状态码：403

```js
{
    "msg" : "Device can't be updated"
}
```

- 状态码 404

```js
{
    "msg" : "not found"
}
```


## 查询设备信息/获取所有设备信息

地址：/appliance/devices  
类型：GET  
权限：普通用户  
请求参数：  

名称|类型|必填|备注|样例
---|---|---|---|---
searchKey|String|否|name和note包含searchKey的字段|                                     
orderBy|json|否|排序方式|{"name" : "desc"}和{"name" : "asc"}
name|String|否||
type|String|否||
location|String|否||
sn|String|否||
manufacturer|String|否||
system|String|否||
createUserName|String|否||
parentEquipmentName|String|否|父装置名|
createdAtStart|DateTime|否|创建时间 起始值|
createdAtEnd|DateTime|否|创建时间 起始值|

请求响应：  

- 状态码：200

```js
{
    "items": [
        device_list_fied,
        device_list_fied,
        ...
    ],
    "meta": {
        "page": fields.Integer,
        "pageSize": fields.Integer,
        "pageCount": fields.Integer,
        "totalCount": fields.Integer
    }
}

device_list_fied = {
        'id': fields.String,
        'name': fields.String,
        'type': fields.String,
        'location': fields.String,
        'system': fields.String,
        'sn': fields.String,
        'manufacture': fields.String,
        'note': fields.String,
        'parentEquipmentName': fields.String,
        'images': fields.String,
        'createdAt': fields.DateTime,
        'updatedAt': fields.DateTime,
        'createUserName': fields.String,
        'updateUserName': fields.String,
        'updateNum': fields.Integer
}
```

## 复刻模板

地址：appliance/device/templates

类型：POST

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注         | 样例 |
| ---- | ------------ | ---- | ------------ | ---- |
| ids  | ObjectIdList | 否   | 一组设备的id |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 审核模板

地址：appliance/device/templates

类型：PUT

权限：管理员 

请求参数：  

| 名称 | 类型         | 必填 | 备注         | 样例 |
| ---- | ------------ | ---- | ------------ | ---- |
| ids  | ObjectIdList | 否   | 一组装置的id |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 获取模板

地址：appliance/device/templates

类型：GET 

权限：管理员或拥有者

请求参数：  

| 名称      | 类型    | 必填 | 备注                                            | 样例 |
| --------- | ------- | ---- | ----------------------------------------------- | ---- |
| searchKey | String  | 否   | 返回name或note包含searchKey的模板。不填返回所有 |      |
| verified  | Boolean | 否   | 为true时，只返回已审核的                        |      |

- 状态码 200  

```
{    
	{
    "items": [
        device_template_field,
        device_template_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}

device_template_fields = {
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'sn': fields.String,
    'manufacturer': fields.String,
    'system': fields.String,
    'note': fields.String,
    'parentEquipmentName': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUserName': fields.String,
    'updateUserName': fields.String,
    'updateNum': fields.Integer,
    'verifyUserName': fields.String
}
```

## 移除模板

地址：appliance/device/templates

类型：DELETE

权限：管理员  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 更新模板信息  

地址：/appliance/device/template/{id}  

类型：PUT  

权限：管理员或拥有者   

请求参数：  

| 名称            | 类型   | 必填 | 备注         | 样例                   |
| --------------- | ------ | ---- | ------------ | ---------------------- |
| name            | String | 否   | 设备名称     | 设备1                  |
| type            | String | 否   | 设备类型     | 冷却设备               |
| sn              | String | 否   | 设备SN       | UJN526542              |
| system          | String | 否   | 设备系统     | 嵌入式Linux            |
| location        | String | 否   | 设备位置     | 桥架1-11               |
| note            | String | 否   | 设备备注     | 设备位于XXX，系统为XXX |
| manufacture     | String | 否   | 设备生产厂商 | 四川长虹               |
| parentEquipment | String | 否   | 父级装置id   | 冷却装置               |

- 状态码 200  

```js
{
   "ok"："True",
   "msg"："success"
}
```

- 状态码 403  

```js
{
    "ok":"False",
	"msg" : "no  updatable" 
} 
```

- 状态码 404  

```js
{
    "ok":"Flase",
	"msg" : "not found"
}
```

## 获取已删除设备  

地址：appliance/devices/recycles  

类型：GET  

权限：普通用户  

请求参数：  

| 名称      | 类型   | 必填 | 备注                                      | 样例 |
| --------- | ------ | ---- | ----------------------------------------- | ---- |
| searchKey | String | 否   | 返回name或note包含searchKey。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        device_field,
        devices_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```
## 获取已删除设备模板

地址：appliance/devices/templates/recycles

类型：GET

权限：普通用户  

请求参数：  

| 名称      | 类型   | 必填 | 备注                                      | 样例 |
| --------- | ------ | ---- | ----------------------------------------- | ---- |
| searchKey | String | 否   | 返回name或note包含searchKey。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        device_template_field,
        device_template_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```

## 撤销删除设备

地址：appliance/devices/recycles  

类型：PUT  

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

## 撤销删除设备模板

地址：appliance/devices/templates/recycles  

类型：PUT  

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

## 彻底删除设备或设备模板

地址：appliance/devices/recycles  

类型：DELETE  

权限：普通用户  

请求参数：  

| 名称  | 类型          | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

------------

# 接口(interface)管理接口(by:yz)

## 添加一个接口  

地址：/appliance/interface  

类型：POST  

权限：普通用户  

请求参数：  

| 名称            | 类型     | 必填 | 备注       | 样例 |
| --------------- | -------- | ---- | ---------- | ---- |
| name            | String   | 是   |            |      |
| type            | String   | 是   |            |      |
| protocol        | String   | 是   |            |      |
| location        | String   | 是   |            |      |
| pcl             | String   | 是   |            |      |
| note            | String   | 否   |            |      |
| parentEquipment | ObjectId | 是   | 所属装置id |      |
| parentDevice    | ObjectId | 是   | 所属设备id |      |

- 状态码 200  

```js
{
    "ok": "True", 
    "msg": "success",
    "id": interface.id
}
```

- 状态码 400  

```js
{
    "msg": form.errors //表单验证失败
}
```

- 状态码 404  

```js
    "msg": "设备/装置不存在，id: "+id  //未找到所属装置或设备
```

## 更新一个接口  

地址：/appliance/interface/{id}  

类型：PUT  

权限：管理员或拥有者

请求参数：   

| 名称            | 类型     | 必填 | 备注       | 样例 |
| --------------- | -------- | ---- | ---------- | ---- |
| name            | String   | 是   | 装置名称   |      |
| type            | String   | 是   | 类型       |      |
| protocol        | String   | 是   | 协议       |      |
| location        | String   | 是   | 位置       |      |
| pcl             | String   | 是   |            |      |
| note            | String   | 否   | 备注       |      |
| parentEquipment | ObjectId | 是   | 所属装置id |      |
| parentDevice    | ObjectId | 是   | 所属设备id |      |

- 状态码 200  

```js
{
    "ok": "True",
    "msg": "success"
}
```

- 状态码 400  

```js
{
    "msg": form.errors //表单验证失败
}    
```

- 状态码 403  

```js
    {
	"msg" : "接口不可被更新"  
}
```

- 状态码 404  

```js
{
	"msg": "设备/装置不存在，id: "+id  //未找到所属装置或设备
}
或
{
    "ok": "False",
    "msg": "接口不存在"
}
```

## 通过id获取一个接口  

地址：appliance/interface/{id}  

类型：GET  

权限：普通用户  

请求参数：无  

- 状态码 200  

```js
{
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'protocol': fields.String,
    'pcl': fields.String,
    'note': fields.String,
    'parentDevice': fields.Nested,
    'parentEquipment': fields.Nested,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUser': fields.String,
    'updateUser': fields.String,
    'updateNum': fields.Integer
}
```

- 状态码 404  

```js
{
    "ok": "False",
	"msg" : "not found"
}
```

## 获取所有接口  

地址：appliance/interfaces  

类型：GET  

权限：普通用户  

请求参数：无  

-  状态码 200  

```js
{
    "items": [
        interface_field,
        interface_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}

interface_fields = {
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'protocol': fields.String,
    'pcl': fields.String,
    'note': fields.String,
    'parentDeviceName': fields.String,
    'parentEquipmentName': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUser': fields.String,
    'updateUser': fields.String,
    'updateNum': fields.Integer
}

```

## 查询接口  

地址：appliance/interfaces  

类型：GET  

权限：普通用户  

请求参数：  

| 名称            | 类型     | 必填 | 备注                                    | 样例 |
| --------------- | -------- | ---- | --------------------------------------- | ---- |
| searchKey       | String   | 否   | 返回name,note中包含searchKey的documents |      |
| name            | String   | 否   |                                         |      |
| location        | String   | 否   |                                         |      |
| type            | String   | 否   |                                         |      |
| protocol        | String   | 否   |                                         |      |
| createUser      | String   | 否   |                                         |      |
| parentEquipment | String   | 否   |                                         |      |
| parentDevice    | String   | 否   |                                         |      |
| createdAtStart  | DateTime | 否   | 创建时间 起始值                         |      |
| createdAtEnd    | DateTime | 否   | 创建时间 终止值                         |      |
| orderBy         | Json     | 否   | 由key和sort组成                         |      |

- 状态码 200  

```js
{
    "items": [
        interface_field,
        interface_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}

interface_fields = {
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'protocol': fields.String,
    'pcl': fields.String,
    'note': fields.String,
    'parentDeviceName': fields.String,
    'parentEquipmentName': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUser': fields.String,
    'updateUser': fields.String,
    'updateNum': fields.Integer
}
```

## 删除一个接口  

地址：appliance/interface/{id}  

类型：DELETE  

权限：管理员或拥有者  

请求参数：无  

- 状态码 200   

```js
{
    "ok": "True",
	"msg" : "success"
}
或
{
    "ok": "True",
	"msg" : "not found"
}
```

## 查询子器材  

地址：appliance/interface/child/{id}  

类型：GET

权限：普通用户  

请求参数：无  

- 状态码 200  

```js
{
    "ok":"True",
    "msg" : {
            'cable': child_cable
    	}
}
```

- 状态码 404  

```js
{
    "ok":"False",
    "msg" : "not found"
}
```

## 批量删除  

地址：appliance/interfaces  

类型：DELETE  

权限：管理员  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectListId | 否   |      |      |

- 状态码 200  

```js
{
    "ok":"True"
    "msg":"success"
}
```

## 查询多个接口的子器材  

地址：appliance/interfaces/child  

类型：GET  

权限：普通用户 

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```
{
    "ok":"True",
    "msg" : {
            'cable': child_cable   //所有接口的子线缆总数
    }
}
```

- 状态码 404  

```
{
    "ok":"False",
    "msg" : "not found"
}
```

## 复刻模板

地址：appliance/interface/templates

类型：POST

权限：管理员  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 审核模板

地址：appliance/interface/templates

类型：PUT

权限：管理员 

请求参数：  

| 名称 | 类型         | 必填 | 备注         | 样例 |
| ---- | ------------ | ---- | ------------ | ---- |
| ids  | ObjectIdList | 否   | 一组装置的id |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 获取模板

地址：appliance/interface/templates

类型：GET 

权限：普通用户  

请求参数：  

| 名称      | 类型    | 必填 | 备注                                            | 样例 |
| --------- | ------- | ---- | ----------------------------------------------- | ---- |
| searchKey | String  | 否   | 返回name或note包含searchKey的模板。不填返回所有 |      |
| verified  | Boolean | 否   | 为true时，只返回已审核的                        |      |

- 状态码 200  

```
{    
	{
    "items": [
        interface_template_field,
        interface_template_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}

interface_template_fields = {
    'id': fields.String,
    'name': fields.String,
    'type': fields.String,
    'location': fields.String,
    'protocol': fields.String,
    'pcl': fields.String,
    'note': fields.String,
    'parentDeviceName': fields.String,
    'parentEquipmentName': fields.String,
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUser': fields.String,
    'updateUser': fields.String,
    'updateNum': fields.Integer,
    'verifyUser': fields.String
}
```

## 移除模板

地址：appliance/interface/templates

类型：DELETE

权限：管理员  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 更新模板信息  

地址：/appliance/interface/template/{id}  

类型：PUT  

权限：管理员或拥有者   

请求参数：  

| 名称            | 类型     | 必填 | 备注       | 样例 |
| --------------- | -------- | ---- | ---------- | ---- |
| name            | String   | 否   | 装置名称   |      |
| type            | String   | 否   | 类型       |      |
| protocol        | String   | 否   | 协议       |      |
| location        | String   | 否   | 位置       |      |
| pcl             | String   | 否   |            |      |
| note            | String   | 否   | 备注       |      |
| parentEquipment | ObjectId | 否   | 所属装置id |      |
| parentDevice    | ObjectId | 否   | 所属设备id |      |

- 状态码 200  

```js
{
   "ok"："True",
   "msg"："success"
}
```

- 状态码 403  

```js
{
    "ok":"False",
	"msg" : "no  updatable" 
} 
```

- 状态码 404  

```js
{
    "ok":"Flase",
	"msg" : "not found"
}
```

## 获取已删除接口  

地址：appliance/interfaces/recycles  

类型：GET  

权限：普通用户  

请求参数：  

| 名称      | 类型   | 必填 | 备注                                      | 样例 |
| --------- | ------ | ---- | ----------------------------------------- | ---- |
| searchKey | String | 否   | 返回name或note包含searchKey。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        interface_field,
        interface_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```
## 获取已删除接口模板

地址：appliance/interfaces/templates/recycles

类型：GET

权限：普通用户  

请求参数：  

| 名称      | 类型   | 必填 | 备注                                      | 样例 |
| --------- | ------ | ---- | ----------------------------------------- | ---- |
| searchKey | String | 否   | 返回name或note包含searchKey。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        interface_template_field,
        interface_template_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```

## 撤销删除接口

地址：appliance/interfaces/recycles  

类型：PUT  

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

## 撤销删除接口模板

地址：appliance/interfaces/templates/recycles  

类型：PUT  

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

## 彻底删除接口或接口模板

地址：appliance/interfaces/recycles  

类型：DELETE  

权限：普通用户  

请求参数：  

| 名称  | 类型          | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

------------


# 线缆（cable）管理接口(by:lcs)

## 通过id获取线缆信息

地址：/appliance/cable/{id}  
类型：GET  
权限：普通用户  
请求参数：无  
请求响应：  

- 状态码：200  

```js
{
    'id': fields.String,
    'name': fields.String,
    'note': fields.String,
    'signalType': fields.String,
    'shieldType': fields.String,
    'isCustom': fields.Boolean,
    'parameterList': fields.String,
    'startEquipment': fields.Nested,
    'endEquipment': fields.Nested,
    'startDevice': fields.Nested,
    'endDevice': fields.Nested,
    'startInterface': fields.Nested,
    'endInterface': fields.Nested,
    'createdAt': fields.DateTime(attribute='created_at', dt_format='iso8601'),
    'updatedAt': fields.DateTime(attribute='updated_at', dt_format='iso8601'),
    'createUserName': fields.String(attribute='create_user.username'),
    'updateUserName': fields.String(attribute='update_user.username'),
    'updateNum': fields.Integer(attribute='update_num')
}
```

- 状态码：404

```js
{
    "msg": "not found"
}
```

## 创建线缆

地址：/appliance/cable  
类型：POST  
权限： 普通用户  
请求参数：  

名称|类型|必填|备注|样例
---|---|---|---|---
name|String|是|线缆名称|局域网电缆
signal_type|String|是|线缆信号类型|控制信号
shield|Sting|是|屏蔽类型|编制层屏蔽
note|String|是|备注|该线缆xxx
isCustom|Boolean|否|是否为定制线缆|默认为False
parameterList|String|否|定制线缆的参数表|name：xx，signal_type：xx....
startInterfaceId|String|是|开始接口ID|5dee646e88941a9f5776ad91
startInterfaceId|String|是||

请求响应：  

- 状态码：200

```js
{
   "ok": "True",
   "msg": "success",
   "id": cable.id
}
```

- 状态码：400

```js
{
    "msg" : "parameter invalid"
}
```

- 状态码：404

```js
{
    "msg" : "Device not found"或"Equipment not found"或"Interface not found"
}
```

## 删除线缆

地址：/appliance/cable/{id}  
类型：DELETE  
权限：管理员或拥有者  
请求参数：  无

请求响应：

- 状态码：200

```js
{
    "ok": "True",
    "msg": "success"
}
或
{
    "ok": "True"
    "msg" : "not found"
}
```

## 批量删除线缆

地址：/appliance/cables  
类型：DELETE  
权限：管理员  
请求参数:  

名称|类型|必填|备注|样例
---|---|---|---|---
ids[]|ObjectIdList|是|要删除的设备ID|

请求响应：  

- 状态码：200

```js
{
    "ok":"True"
    "msg":"success"
}
```

## 修改线缆信息  

地址：/appliance/cable/{id}  
类型：PUT  
权限：管理员或拥有者  
请求参数：  

名称|类型|必填|备注|样例
---|---|---|---|---
name|String|是|线缆名称|局域网电缆
signal_type|String|是|线缆信号类型|控制信号
shield|Sting|是|屏蔽类型|编制层屏蔽
note|String|否|备注|该线缆xxx
isCustom|Boolean|否|是否为定制线缆|默认为否
parameterList|String|否|定制线缆的参数表|name：xx，signal_type：xx....
startInterfaceId|String|是|开始接口ID|5dee646e88941a9f5776ad91
endInterfaceId|String|是||

请求响应：

- 状态码：200

```js
{
    "ok":"True"
    "msg":"success"
}
```

- 状态码：400

```js
{
    "msg" : "params invalid"
}
```

- 状态码:403

```js
{
    "msg" : "Cable can't be updated"
}
```

- 状态码：404

```js
{
    "msg" : "not found"
}
```

## 查询线缆信息/获取所有线缆信息

地址：/appliance/cables  
类型：GET  
权限：普通用户  
请求参数：  

名称|类型|必填|备注|样例
---|---|---|---|---
searchKey|String|否|返回name和note包含searchKey的线缆|
 name           | String | 否   |                                   |      
 signalType     | String | 否   |                                   |      
 shieldType     | String | 否   |                                   |      
 isCustom | Boolean | 否 | | 
 startEquipment | String | 否   | 起始装置名称                      |      
 endEquipment   | String | 否   |                                   |      
 startDevice    | String | 否   |                                   |      
 endDevice      | String | 否   |                                   |      
 startInterface | String | 否   |                                   |      
 endInterface   | String | 否   |                                   |      
 createUser     | String | 否   |                                   |      
 createdAtStart | String | 否   |                                   |      
 createdAtEnd   | String | 否   |                                   |      
 orderBy        | Json   | 否   |                                   |      

请求响应：  

- 状态码：200  

```js
{
    "items": [
        cable_list_fields,
        cable_list_fields,
        ...
    ],
    "meta": {
        "page": fields.Integer,
        "pageSize": fields.Integer,
        "pageCount": fields.Integer,
        "totalCount": fields.Integer
    }
 cable_list_fields = {
        'id': fields.String,
        'name': fields.String,
        'note': fields.String,
        'signalType': fields.String,
        'shieldType': fields.String,
        'isCustom': fields.Boolean,
        'parameterList': fields.String,
        'startEquipment': fields.Nested,
        'endEquipment': fields.Nested,
        'startDevice': fields.Nested,
        'endDevice': fields.Nested,
        'startInterface': fields.Nested,
        'endInterface': fields.Nested,
        'createdAt': fields.DateTime(attribute='created_at', dt_format='iso8601'),
        'updatedAt': fields.DateTime(attribute='updated_at', dt_format='iso8601'),
        'createUserName': fields.String(attribute='create_user.username'),
        'updateUserName': fields.String(attribute='update_user.username'),
        'updateNum': fields.Integer(attribute='update_num')
    }
}


```

## 复刻模板

地址：appliance/cable/templates

类型：POST

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注         | 样例 |
| ---- | ------------ | ---- | ------------ | ---- |
| ids  | ObjectIdList | 否   | 一组线缆的id |      |

- 状态码 200  

```
{   
	"ok":"True",  
	"msg" : "success"
}
```

## 审核模板

地址：appliance/cable/templates

类型：PUT

权限：管理员 

请求参数：  

| 名称 | 类型         | 必填 | 备注         | 样例 |
| ---- | ------------ | ---- | ------------ | ---- |
| ids  | ObjectIdList | 否   | 一组装置的id |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 获取模板

地址：appliance/cable/templates

类型：GET 

权限：普通用户  

请求参数：  

| 名称      | 类型    | 必填 | 备注                                            | 样例 |
| --------- | ------- | ---- | ----------------------------------------------- | ---- |
| searchKey | String  | 否   | 返回name或note包含searchKey的模板。不填返回所有 |      |
| verified  | Boolean | 否   | 为true时，只返回已审核的                        |      |

- 状态码 200  

```
{    
	{
    "items": [
        cable_template_field,
        cable_template_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}

cable_template_fields = {
    'id': fields.String,
    'name': fields.String,
    'signalType': fields.String,
    'shieldType': fields.String,
    'isCustom': fields.Boolean,
    'parameterList': fields.String，
    'createdAt': fields.DateTime,
    'updatedAt': fields.DateTime,
    'createUser': fields.String,
    'updateUser': fields.String,
    'updateNum': fields.Integer,
	'verifyUser': fields.String
}
```

## 移除模板

地址：appliance/cable/templates

类型：DELETE

权限：管理员  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```
{   
	"ok":"True", 
	"msg" : "success"
}
```

## 更新模板信息  

地址：/appliance/cable/template/{id}  

类型：PUT  

权限：管理员或拥有者   

请求参数：  

| 名称             | 类型    | 必填 | 备注             | 样例                          |
| ---------------- | ------- | ---- | ---------------- | ----------------------------- |
| name             | String  | 否   | 线缆名称         | 局域网电缆                    |
| signal_type      | String  | 否   | 线缆信号类型     | 控制信号                      |
| shield           | Sting   | 否   | 屏蔽类型         | 编制层屏蔽                    |
| note             | String  | 否   | 备注             | 该线缆xxx                     |
| isCustom         | Boolean | 否   | 是否为定制线缆   | 默认为否                      |
| parameterList    | String  | 否   | 定制线缆的参数表 | name：xx，signal_type：xx.... |
| startInterfaceId | String  | 否   | 开始接口ID       | 5dee646e88941a9f5776ad91      |
| endInterfaceId   | String  | 否   |                  |                               |

- 状态码 200  

```js
{
   "ok"："True",
   "msg"："success"
}
```

- 状态码 403  

```js
{
    "ok":"False",
	"msg" : "no  updatable" 
} 
```

- 状态码 404  

```js
{
    "ok":"Flase",
	"msg" : "not found"
}
```

## 获取已删除线缆  

地址：appliance/cables/recycles  

类型：GET  

权限：普通用户  

请求参数：  

| 名称      | 类型   | 必填 | 备注                                      | 样例 |
| --------- | ------ | ---- | ----------------------------------------- | ---- |
| searchKey | String | 否   | 返回name或note包含searchKey。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        cable_list_field,
        cable_list_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```
## 获取已删除线缆模板

地址：appliance/cables/templates/recycles

类型：GET

权限：普通用户  

请求参数：  

| 名称      | 类型   | 必填 | 备注                                      | 样例 |
| --------- | ------ | ---- | ----------------------------------------- | ---- |
| searchKey | String | 否   | 返回name或note包含searchKey。不填返回所有 |      |

- 状态码 200  

```js
{
    "items": [
        cable_template_field,
        cable_template_field,
        ...
    ],
    "meta": {
        'page': form.page.data,
        'pageSize': form.pageSize.data,
        'pageCount': pagination.pages,
        'totalCount': pagination.total
    }
}
```

## 撤销删除线缆

地址：appliance/cables/recycles  

类型：PUT  

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

## 撤销删除线缆模板

地址：appliance/cables/templates/recycles  

类型：PUT  

权限：普通用户  

请求参数：  

| 名称 | 类型         | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

## 彻底删除线缆或线缆模板

地址：appliance/cables/recycles  

类型：DELETE  

权限：普通用户  

请求参数：  

| 名称  | 类型          | 必填 | 备注 | 样例 |
| ---- | ------------ | ---- | ---- | ---- |
| ids  | ObjectIdList | 否   |      |      |

- 状态码 200  

```js
{
    "ok"="True",
    "msg"='success'
}
```

------------

